<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: ../../index.php');
    exit();
}

// Handle delete registration
if ($_POST && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $registration_id = $_POST['registration_id'];
    
    try {
        // Verify ownership
        $stmt = $pdo->prepare("
            SELECT r.* FROM registrations r 
            JOIN athletes a ON r.athlete_id = a.id 
            WHERE r.id = ? AND a.user_id = ?
        ");
        $stmt->execute([$registration_id, $_SESSION['user_id']]);
        $registration = $stmt->fetch();
        
        if ($registration && $registration['payment_status'] !== 'verified') {
            $stmt = $pdo->prepare("DELETE FROM registrations WHERE id = ?");
            $stmt->execute([$registration_id]);
            
            sendNotification("Pendaftaran berhasil dihapus!", 'success');
        } else {
            sendNotification("Pendaftaran tidak dapat dihapus atau sudah terverifikasi.", 'danger');
        }
    } catch (Exception $e) {
        sendNotification("Gagal menghapus pendaftaran: " . $e->getMessage(), 'danger');
    }
}

// Get user's registrations for competitions with open registration and active status
$stmt = $pdo->prepare("
    SELECT r.*, c.nama_perlombaan, c.tanggal_pelaksanaan, a.nama as athlete_name, 
           cc.nama_kategori as category_name, ac.nama_kategori as age_category_name,
           ct.nama_kompetisi, ct.biaya_pendaftaran, k.nama_kontingen, r.payment_proof,
           u.nama as user_name, u.email, u.whatsapp,
           CASE 
               WHEN c.registration_status IS NOT NULL THEN c.registration_status
               WHEN CURDATE() < c.tanggal_open_regist THEN 'coming_soon'
               WHEN CURDATE() BETWEEN c.tanggal_open_regist AND c.tanggal_close_regist THEN 'open_regist'
               WHEN CURDATE() > c.tanggal_close_regist THEN 'close_regist'
               ELSE 'coming_soon'
           END as current_registration_status
    FROM registrations r 
    JOIN competitions c ON r.competition_id = c.id 
    JOIN athletes a ON r.athlete_id = a.id 
    JOIN kontingen k ON r.kontingen_id = k.id
    JOIN users u ON a.user_id = u.id
    LEFT JOIN competition_categories cc ON r.category_id = cc.id
    LEFT JOIN age_categories ac ON r.age_category_id = ac.id
    LEFT JOIN competition_types ct ON r.competition_type_id = ct.id
    WHERE a.user_id = ? AND c.status = 'active' 
    AND (c.registration_status = 'open_regist' OR 
         (CURDATE() BETWEEN c.tanggal_open_regist AND c.tanggal_close_regist))
    ORDER BY r.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$registrations = $stmt->fetchAll();

// Group registrations by competition
$user_competitions = [];
foreach ($registrations as $reg) {
    $comp_id = $reg['competition_id'];
    if (!isset($user_competitions[$comp_id])) {
        $user_competitions[$comp_id] = [
            'info' => $reg,
            'athletes' => []
        ];
    }
    $user_competitions[$comp_id]['athletes'][] = $reg;
}

// Get available competitions with open registration
$stmt = $pdo->prepare("
    SELECT c.*, 
           COUNT(r.id) as total_registrations,
           CASE 
               WHEN c.registration_status IS NOT NULL THEN c.registration_status
               WHEN CURDATE() < c.tanggal_open_regist THEN 'coming_soon'
               WHEN CURDATE() BETWEEN c.tanggal_open_regist AND c.tanggal_close_regist THEN 'open_regist'
               WHEN CURDATE() > c.tanggal_close_regist THEN 'close_regist'
               ELSE 'coming_soon'
           END as current_registration_status
    FROM competitions c
    LEFT JOIN registrations r ON c.id = r.competition_id
    WHERE c.status = 'active' 
    AND (c.registration_status = 'open_regist' OR 
         (CURDATE() BETWEEN c.tanggal_open_regist AND c.tanggal_close_regist))
    GROUP BY c.id
    ORDER BY c.tanggal_pelaksanaan ASC
");
$stmt->execute();
$available_competitions = $stmt->fetchAll();

// Get match data for competitions where user has registered athletes
$user_competition_ids = array_keys($user_competitions);
$matches_data = [];
$schedules_data = [];
$brackets_data = [];
$scores_data = [];
$medals_data = [];

if (!empty($user_competition_ids)) {
    $placeholders = str_repeat('?,', count($user_competition_ids) - 1) . '?';
    
    // Get tournament brackets (using correct table name)
    $stmt = $pdo->prepare("
        SELECT tb.*, c.nama_perlombaan, cc.nama_kategori, ac.nama_kategori as age_category_name,
               ct.nama_kompetisi, a1.nama as athlete1_name, a2.nama as athlete2_name,
               k1.nama_kontingen as kontingen1_name, k2.nama_kontingen as kontingen2_name,
               'scheduled' as status, tb.match_number as match_order
        FROM tournament_brackets tb
        JOIN competitions c ON tb.competition_id = c.id
        LEFT JOIN competition_categories cc ON tb.category_id = cc.id
        LEFT JOIN age_categories ac ON tb.age_category_id = ac.id
        LEFT JOIN competition_types ct ON tb.competition_id = ct.competition_id
        LEFT JOIN athletes a1 ON tb.participant1_id = a1.id
        LEFT JOIN athletes a2 ON tb.participant2_id = a2.id
        LEFT JOIN kontingen k1 ON a1.kontingen_id = k1.id
        LEFT JOIN kontingen k2 ON a2.kontingen_id = k2.id
        WHERE tb.competition_id IN ($placeholders)
        ORDER BY tb.round_number, tb.match_number
    ");
    $stmt->execute($user_competition_ids);
    $brackets_data = $stmt->fetchAll();
    
    // Get match schedules
    $stmt = $pdo->prepare("
        SELECT ms.*, c.nama_perlombaan, 
               ms.tanggal_pertandingan as match_date, ms.waktu_pertandingan as match_time,
               ms.venue as arena, ms.status,
               '' as nama_kategori, '' as age_category_name, '' as nama_kompetisi,
               '' as athlete1_name, '' as athlete2_name,
               '' as kontingen1_name, '' as kontingen2_name
        FROM match_schedules ms
        JOIN tournament_brackets tb ON ms.bracket_id = tb.id
        JOIN competitions c ON tb.competition_id = c.id
        WHERE tb.competition_id IN ($placeholders)
        ORDER BY ms.tanggal_pertandingan, ms.waktu_pertandingan
    ");
    $stmt->execute($user_competition_ids);
    $schedules_data = $stmt->fetchAll();
    
    // Get TGR scores
    $stmt = $pdo->prepare("
        SELECT ts.*, c.nama_perlombaan, a.nama as athlete_name, k.nama_kontingen,
               '' as nama_kategori, '' as age_category_name, '' as nama_kompetisi,
               (COALESCE(ts.juri1_score, 0) + COALESCE(ts.juri2_score, 0) + COALESCE(ts.juri3_score, 0) + 
                COALESCE(ts.juri4_score, 0) + COALESCE(ts.juri5_score, 0)) as teknik_score,
               0 as gerakan_score, 0 as ritme_score
        FROM tgr_scores ts
        JOIN tournament_brackets tb ON ts.bracket_id = tb.id
        JOIN competitions c ON tb.competition_id = c.id
        JOIN athletes a ON ts.athlete_id = a.id
        JOIN kontingen k ON a.kontingen_id = k.id
        WHERE tb.competition_id IN ($placeholders)
        ORDER BY ts.total_score DESC
    ");
    $stmt->execute($user_competition_ids);
    $scores_data = $stmt->fetchAll();
    
    // Get medals (using correct table name)
    $stmt = $pdo->prepare("
        SELECT m.*, c.nama_perlombaan, a.nama as athlete_name, k.nama_kontingen,
               cc.nama_kategori, ac.nama_kategori as age_category_name,
               '' as nama_kompetisi
        FROM medal_results m
        JOIN competitions c ON m.competition_id = c.id
        JOIN athletes a ON m.athlete_id = a.id
        JOIN kontingen k ON a.kontingen_id = k.id
        LEFT JOIN competition_categories cc ON m.category_id = cc.id
        LEFT JOIN age_categories ac ON m.age_category_id = ac.id
        WHERE m.competition_id IN ($placeholders)
        ORDER BY 
            CASE m.medal_type 
                WHEN 'gold' THEN 1 
                WHEN 'silver' THEN 2 
                WHEN 'bronze' THEN 3 
                ELSE 4 
            END
    ");
    $stmt->execute($user_competition_ids);
    $medals_data = $stmt->fetchAll();
}

// Get notification
$notification = getNotification();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Pendaftaran Atlet - User Panel</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* Additional styles for athlete registration */
        .registrations-container {
            display: flex;
            flex-direction: column;
            gap: 30px;
        }

        .competition-registration-card {
            background: white;
            border-radius: 15px;
            box-shadow: var(--shadow-lg);
            overflow: hidden;
        }

        .competition-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .competition-info h3 {
            margin: 0 0 10px 0;
            font-size: 1.4rem;
        }

        .competition-meta {
            display: flex;
            align-items: center;
            gap: 20px;
            opacity: 0.9;
        }

        .competition-date, .kontingen-name {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 0.9rem;
        }

        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-open_regist {
            background-color: #dcfce7;
            color: #166534;
        }

        .competition-actions {
            display: flex;
            gap: 10px;
        }

        .btn-upload-kontingen, .btn-invoice-kontingen {
            background: rgba(255,255,255,0.2);
            color: white;
            border: 2px solid rgba(255,255,255,0.3);
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            text-decoration: none;
        }

        .btn-upload-kontingen:hover, .btn-invoice-kontingen:hover {
            background: rgba(255,255,255,0.3);
            border-color: rgba(255,255,255,0.5);
        }

        .athletes-list {
            padding: 25px;
        }

        .athletes-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--border-color);
        }

        .athletes-header h4 {
            color: var(--primary-color);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.2rem;
        }

        .athletes-summary .total-cost {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--success-color);
        }

        .athletes-table-container {
            overflow-x: auto;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: var(--shadow);
        }

        .athletes-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            font-size: 0.9rem;
        }

        .athletes-table th {
            background: var(--light-color);
            color: var(--dark-color);
            padding: 15px 12px;
            text-align: left;
            font-weight: 600;
            white-space: nowrap;
        }

        .athletes-table td {
            padding: 15px 12px;
            border-bottom: 1px solid var(--border-color);
            vertical-align: top;
        }

        .athlete-row:hover {
            background-color: #f9fafb;
        }

        .athlete-name strong {
            display: block;
            color: var(--primary-color);
            margin-bottom: 2px;
        }

        .registration-date {
            color: var(--text-light);
            font-size: 0.8rem;
        }

        .category-info {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }

        .category-name {
            font-weight: 600;
            color: var(--text-color);
        }

        .age-category {
            color: var(--text-light);
            font-size: 0.8rem;
        }

        .competition-type {
            background: #dbeafe;
            color: var(--primary-color);
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .price-amount {
            color: var(--success-color);
            font-weight: 600;
        }

        .payment-status {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-pending {
            background-color: #fef3c7;
            color: #92400e;
        }

        .status-paid {
            background-color: #dbeafe;
            color: var(--primary-color);
        }

        .status-verified {
            background-color: #dcfce7;
            color: #166534;
        }

        .payment-proof {
            margin-top: 5px;
        }

        .view-proof {
            color: var(--primary-color);
            text-decoration: none;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .view-proof:hover {
            text-decoration: underline;
        }

        .action-buttons {
            display: flex;
            gap: 4px;
            flex-wrap: wrap;
        }

        .btn-action {
            padding: 6px 8px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
            min-width: 32px;
            height: 32px;
        }

        .btn-upload {
            background: var(--success-color);
            color: white;
        }

        .btn-upload:hover {
            background: #059669;
        }

        .btn-edit {
            background: var(--warning-color);
            color: white;
        }

        .btn-edit:hover {
            background: #d97706;
        }

        .btn-delete {
            background: var(--danger-color);
            color: white;
        }

        .btn-delete:hover {
            background: #dc2626;
        }

        .btn-invoice {
            background: var(--dark-color);
            color: white;
        }

        .btn-invoice:hover {
            background: #374151;
        }

        .btn-download {
            background: var(--primary-color);
            color: white;
        }

        .btn-download:hover {
            background: var(--secondary-color);
        }

        .btn-print {
            background: #8b5cf6;
            color: white;
        }

        .btn-print:hover {
            background: #7c3aed;
        }

        .kontingen-actions-bar {
            background: var(--light-color);
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            border: 1px solid var(--border-color);
        }

        .summary-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }

        .stat-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 15px;
            background: white;
            border-radius: 8px;
            box-shadow: var(--shadow);
        }

        .stat-label {
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.9rem;
        }

        .stat-value {
            font-weight: 700;
            font-size: 1rem;
        }

        .total-cost-item {
            border-left: 4px solid var(--success-color);
        }

        .total-amount {
            color: var(--success-color);
            font-size: 1.1rem;
        }

        .text-success { color: var(--success-color); }
        .text-info { color: var(--primary-color); }
        .text-warning { color: var(--warning-color); }

        .kontingen-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .btn-kontingen {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            text-decoration: none;
        }

        .btn-view-invoice {
            background: var(--primary-color);
            color: white;
        }

        .btn-view-invoice:hover {
            background: var(--secondary-color);
        }

        .btn-download-invoice {
            background: var(--success-color);
            color: white;
        }

        .btn-download-invoice:hover {
            background: #059669;
        }

        .btn-print-invoice {
            background: #8b5cf6;
            color: white;
        }

        .btn-print-invoice:hover {
            background: #7c3aed;
        }

        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-light);
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 15px;
            opacity: 0.6;
        }

        .empty-state p {
            font-size: 1.1rem;
            margin-bottom: 5px;
        }

        .empty-state small {
            font-size: 0.9rem;
        }

        /* Modal styles */
        .modal-header {
            background: var(--primary-color);
            color: white;
            padding: 20px;
            border-radius: 15px 15px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h3 {
            margin: 0;
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .close:hover {
            opacity: 0.7;
        }

        .modal-body {
            padding: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: var(--text-color);
        }

        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s, box-shadow 0.3s;
        }

        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .form-help {
            font-size: 12px;
            color: var(--text-light);
            margin-top: 5px;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 20px;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: background 0.3s;
        }

        .btn-primary:hover {
            background: var(--secondary-color);
        }

        .btn-secondary {
            background: var(--dark-color);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: background 0.3s;
        }

        .btn-secondary:hover {
            background: #374151;
        }

        .btn-danger {
            background: var(--danger-color);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: background 0.3s;
        }

        .btn-danger:hover {
            background: #dc2626;
        }

        .delete-confirmation {
            text-align: center;
        }

        .delete-confirmation i {
            font-size: 3rem;
            color: var(--danger-color);
            margin-bottom: 15px;
        }

        .delete-confirmation h4 {
            color: var(--text-color);
            margin-bottom: 10px;
        }

        .delete-confirmation p {
            color: var(--text-light);
            margin-bottom: 20px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .athletes-table-container {
                font-size: 0.8rem;
            }
            
            .athletes-table th,
            .athletes-table td {
                padding: 8px 4px;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 2px;
            }
            
            .btn-action {
                width: 100%;
                justify-content: flex-start;
                gap: 8px;
            }
            
            .athletes-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .summary-stats {
                grid-template-columns: 1fr;
            }
            
            .kontingen-actions {
                flex-direction: column;
            }
            
            .competition-actions {
                flex-direction: column;
                gap: 8px;
            }
        }

        /* Navigation Tabs */
        .nav-tabs-container {
            background: white;
            border-radius: 10px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
            overflow: hidden;
        }

        .nav-tabs {
            display: flex;
            border-bottom: 1px solid var(--border-color);
        }

        .nav-tab {
            flex: 1;
            padding: 20px;
            text-align: center;
            text-decoration: none;
            color: var(--text-light);
            font-weight: 600;
            transition: all 0.3s;
            border-bottom: 3px solid transparent;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .nav-tab:hover {
            background: var(--light-color);
            color: var(--primary-color);
        }

        .nav-tab.active {
            color: var(--primary-color);
            background: var(--light-color);
            border-bottom-color: var(--primary-color);
        }

        .nav-tab i {
            font-size: 1.1rem;
        }

        /* Tab Content */
        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        /* Competition Cards */
        .competitions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 25px;
        }

        .competition-card {
            background: white;
            border-radius: 15px;
            box-shadow: var(--shadow-lg);
            overflow: hidden;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .competition-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }

        .competition-card-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .competition-card-header h3 {
            margin: 0;
            font-size: 1.2rem;
        }

        .competition-card-body {
            padding: 20px;
        }

        .competition-info-item {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 12px;
            color: var(--text-color);
        }

        .competition-info-item i {
            color: var(--primary-color);
            width: 16px;
        }

        .competition-description {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid var(--border-color);
        }

        .competition-description p {
            color: var(--text-light);
            font-size: 0.9rem;
            line-height: 1.5;
        }

        .competition-card-footer {
            padding: 20px;
            border-top: 1px solid var(--border-color);
            display: flex;
            gap: 10px;
        }

        /* Sub Navigation Tabs */
        .sub-nav-tabs {
            display: flex;
            background: white;
            border-radius: 10px;
            box-shadow: var(--shadow);
            margin-bottom: 25px;
            overflow: hidden;
        }

        .sub-nav-tab {
            flex: 1;
            padding: 15px 20px;
            background: none;
            border: none;
            cursor: pointer;
            font-weight: 600;
            color: var(--text-light);
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            border-bottom: 3px solid transparent;
        }

        .sub-nav-tab:hover {
            background: var(--light-color);
            color: var(--primary-color);
        }

        .sub-nav-tab.active {
            color: var(--primary-color);
            background: var(--light-color);
            border-bottom-color: var(--primary-color);
        }

        .sub-tab-content {
            display: none;
        }

        .sub-tab-content.active {
            display: block;
        }

        /* Brackets */
        .brackets-container {
            display: flex;
            flex-direction: column;
            gap: 30px;
        }

        .bracket-section {
            background: white;
            border-radius: 15px;
            box-shadow: var(--shadow-lg);
            overflow: hidden;
        }

        .bracket-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 20px;
        }

        .bracket-header h3 {
            margin: 0 0 10px 0;
        }

        .bracket-category {
            display: flex;
            gap: 15px;
            opacity: 0.9;
        }

        .bracket-category span {
            background: rgba(255,255,255,0.2);
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 0.8rem;
        }

.bracket-tree {
    padding: 25px;
}

.bracket-round {
    margin-bottom: 30px;
}

.bracket-round h4 {
    color: var(--primary-color);
    margin-bottom: 15px;
    font-size: 1.1rem;
}

.bracket-matches {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 15px;
}

.bracket-match {
    border: 2px solid var(--border-color);
    border-radius: 10px;
    padding: 15px;
    background: white;
    transition: all 0.3s;
}

.bracket-match.completed {
    border-color: var(--success-color);
    background: #f0fdf4;
}

.bracket-match.ongoing {
    border-color: var(--warning-color);
    background: #fffbeb;
}

.match-participants {
    margin-bottom: 10px;
}

.participant {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 12px;
    margin-bottom: 5px;
    border-radius: 6px;
    background: var(--light-color);
}

.participant.winner {
    background: #dcfce7;
    border: 2px solid var(--success-color);
    font-weight: bold;
}

.athlete-name {
    font-weight: 600;
    color: var(--text-color);
}

.kontingen-name {
    font-size: 0.8rem;
    color: var(--text-light);
}

.score {
    font-weight: bold;
    color: var(--primary-color);
    font-size: 1.1rem;
}

.vs {
    text-align: center;
    font-weight: bold;
    color: var(--text-light);
    margin: 5px 0;
}

.match-status {
    text-align: center;
}

/* Schedules */
.schedules-container {
    background: white;
    border-radius: 15px;
    box-shadow: var(--shadow-lg);
    overflow: hidden;
}

.schedules-table-container {
    overflow-x: auto;
}

.schedules-table {
    width: 100%;
    border-collapse: collapse;
}

.schedules-table th {
    background: var(--light-color);
    color: var(--dark-color);
    padding: 15px 12px;
    text-align: left;
    font-weight: 600;
    white-space: nowrap;
}

.schedules-table td {
    padding: 15px 12px;
    border-bottom: 1px solid var(--border-color);
    vertical-align: top;
}

.schedules-table tr:hover {
    background-color: #f9fafb;
}

.schedule-datetime {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.schedule-date {
    font-weight: 600;
    color: var(--text-color);
}

.schedule-time {
    font-size: 0.9rem;
    color: var(--text-light);
}

/* Scores */
.scores-container {
    background: white;
    border-radius: 15px;
    box-shadow: var(--shadow-lg);
    overflow: hidden;
}

.scores-table-container {
    overflow-x: auto;
}

.scores-table {
    width: 100%;
    border-collapse: collapse;
}

.scores-table th {
    background: var(--light-color);
    color: var(--dark-color);
    padding: 15px 12px;
    text-align: left;
    font-weight: 600;
    white-space: nowrap;
}

.scores-table td {
    padding: 15px 12px;
    border-bottom: 1px solid var(--border-color);
    vertical-align: top;
}

.scores-table tr:hover {
    background-color: #f9fafb;
}

.ranking {
    display: flex;
    align-items: center;
    gap: 8px;
}

.ranking-1 { color: #ffd700; }
.ranking-2 { color: #c0c0c0; }
.ranking-3 { color: #cd7f32; }

.score-value {
    font-weight: 600;
    color: var(--primary-color);
}

.total-score {
    font-weight: bold;
    color: var(--success-color);
    font-size: 1.1rem;
}

/* Medals */
.medals-container {
    display: flex;
    flex-direction: column;
    gap: 25px;
}

.medals-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}

.medal-card {
    background: white;
    border-radius: 15px;
    box-shadow: var(--shadow-lg);
    padding: 20px;
    text-align: center;
    position: relative;
    overflow: hidden;
}

.medal-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
}

.medal-card.medal-gold::before { background: #ffd700; }
.medal-card.medal-silver::before { background: #c0c0c0; }
.medal-card.medal-bronze::before { background: #cd7f32; }

.medal-icon {
    font-size: 3rem;
    margin-bottom: 15px;
}

.medal-card.medal-gold .medal-icon { color: #ffd700; }
.medal-card.medal-silver .medal-icon { color: #c0c0c0; }
.medal-card.medal-bronze .medal-icon { color: #cd7f32; }

.medal-info h4 {
    margin: 0 0 10px 0;
    color: var(--text-color);
}

.medal-info .kontingen {
    color: var(--text-light);
    font-weight: 600;
    margin-bottom: 5px;
}

.medal-info .competition {
    color: var(--text-light);
    font-size: 0.9rem;
    margin-bottom: 10px;
}

.medal-type {
    font-weight: bold;
    font-size: 0.9rem;
    margin-top: 15px;
    padding: 8px 16px;
    border-radius: 20px;
    display: inline-block;
}

.medal-card.medal-gold .medal-type {
    background: #ffd700;
    color: #b45309;
}

.medal-card.medal-silver .medal-type {
    background: #c0c0c0;
    color: #374151;
}

.medal-card.medal-bronze .medal-type {
    background: #cd7f32;
    color: white;
}

/* Medal Recap */
.medal-recap-container {
    background: white;
    border-radius: 15px;
    box-shadow: var(--shadow-lg);
    overflow: hidden;
}

.medal-recap-table-container {
    overflow-x: auto;
}

.medal-recap-table {
    width: 100%;
    border-collapse: collapse;
}

.medal-recap-table th {
    background: var(--light-color);
    color: var(--dark-color);
    padding: 15px 12px;
    text-align: center;
    font-weight: 600;
    white-space: nowrap;
}

.medal-recap-table th:first-child,
.medal-recap-table th:nth-child(2) {
    text-align: left;
}

.medal-recap-table td {
    padding: 15px 12px;
    border-bottom: 1px solid var(--border-color);
    text-align: center;
    vertical-align: middle;
}

.medal-recap-table td:first-child,
.medal-recap-table td:nth-child(2) {
    text-align: left;
}

.medal-recap-table tr:hover {
    background-color: #f9fafb;
}

.medal-col.gold { color: #ffd700; }
.medal-col.silver { color: #c0c0c0; }
.medal-col.bronze { color: #cd7f32; }

.medal-count {
    font-weight: bold;
    font-size: 1.1rem;
}

.medal-count.gold { color: #ffd700; }
.medal-count.silver { color: #c0c0c0; }
.medal-count.bronze { color: #cd7f32; }

.total-count {
    font-size: 1.2rem;
    color: var(--primary-color);
}

/* Responsive Design */
@media (max-width: 768px) {
    .competitions-grid {
        grid-template-columns: 1fr;
    }
    
    .sub-nav-tabs {
        flex-direction: column;
    }
    
    .bracket-matches {
        grid-template-columns: 1fr;
    }
    
    .medals-grid {
        grid-template-columns: 1fr;
    }
    
    .schedules-table,
    .scores-table,
    .medal-recap-table {
        font-size: 0.9rem;
    }
    
    .schedules-table th,
    .schedules-table td,
    .scores-table th,
    .scores-table td,
    .medal-recap-table th,
    .medal-recap-table td {
        padding: 8px 6px;
    }
}
</style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-fist-raised"></i>
                <span>User Panel</span>
            </div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="data-atlet.php"><i class="fas fa-user-ninja"></i> Data Atlet</a></li>
            <li><a href="perlombaan.php" class="active"><i class="fas fa-trophy"></i> Perlombaan</a></li>
            <li><a href="akun-saya.php"><i class="fas fa-user-circle"></i> Akun Saya</a></li>
            <li><a href="../../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="page-header">
            <h1 class="page-title">Menu Pendaftaran Atlet</h1>
            <p class="page-subtitle">Kelola pendaftaran atlet pada perlombaan yang sedang buka pendaftaran</p>
        </div>

        <!-- Navigation Tabs -->
        <div class="nav-tabs-container">
            <div class="nav-tabs">
                <a href="#registered-athletes" class="nav-tab active" onclick="showTab('registered-athletes', this)">
                    <i class="fas fa-users"></i> Atlet Terdaftar
                </a>
                <a href="#available-competitions" class="nav-tab" onclick="showTab('available-competitions', this)">
                    <i class="fas fa-trophy"></i> Perlombaan Tersedia
                </a>
                <a href="#matches" class="nav-tab" onclick="showTab('matches', this)">
                    <i class="fas fa-medal"></i> Pertandingan
                </a>
            </div>
        </div>

        <?php if ($notification): ?>
            <div class="alert alert-<?php echo $notification['type'] === 'success' ? 'success' : 'danger'; ?>">
                <i class="fas fa-<?php echo $notification['type'] === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i> 
                <?php echo $notification['message']; ?>
            </div>
        <?php endif; ?>

        <!-- Tab Content: Registered Athletes -->
        <div id="registered-athletes" class="tab-content active">
            <!-- Registered Athletes Section -->
            <?php if (empty($user_competitions)): ?>
                <div class="empty-state">
                    <i class="fas fa-user-plus"></i>
                    <p>Belum Ada Atlet Terdaftar</p>
                    <small>Anda belum mendaftarkan atlet ke perlombaan yang sedang buka pendaftaran.</small>
                </div>
            <?php else: ?>
            <div class="registrations-container">
                <?php foreach ($user_competitions as $comp_id => $comp_data): ?>
                    <div class="competition-registration-card">
                        <div class="competition-header">
                            <div class="competition-info">
                                <h3><?php echo htmlspecialchars($comp_data['info']['nama_perlombaan']); ?></h3>
                                <div class="competition-meta">
                                    <span class="competition-date">
                                        <i class="fas fa-calendar"></i>
                                        <?php echo formatDate($comp_data['info']['tanggal_pelaksanaan']); ?>
                                    </span>
                                    <span class="kontingen-name">
                                        <i class="fas fa-flag"></i>
                                        <?php echo htmlspecialchars($comp_data['info']['nama_kontingen']); ?>
                                    </span>
                                    <span class="status-badge status-<?php echo $comp_data['info']['current_registration_status']; ?>">
                                        Buka Pendaftaran
                                    </span>
                                </div>
                            </div>
                            <div class="competition-actions">
                                <?php 
                                $has_unpaid = false;
                                foreach ($comp_data['athletes'] as $athlete) {
                                    if ($athlete['payment_status'] !== 'verified') {
                                        $has_unpaid = true;
                                        break;
                                    }
                                }
                                ?>
                                
                                <?php if ($has_unpaid): ?>
                                    <button class="btn-upload-kontingen" onclick="uploadKontingenPayment(<?php echo $comp_id; ?>, '<?php echo htmlspecialchars($comp_data['info']['nama_perlombaan']); ?>')">
                                        <i class="fas fa-upload"></i> Upload Bukti Kontingen
                                    </button>
                                <?php endif; ?>
                                
                                <button class="btn-invoice-kontingen" onclick="viewKontingenInvoice(<?php echo $comp_id; ?>)">
                                    <i class="fas fa-file-invoice-dollar"></i> Invoice Kontingen
                                </button>
                            </div>
                        </div>

                        <div class="athletes-list">
                            <div class="athletes-header">
                                <h4><i class="fas fa-users"></i> Daftar Atlet Terdaftar (<?php echo count($comp_data['athletes']); ?> atlet)</h4>
                                <div class="athletes-summary">
                                    <?php 
                                    $total_amount = 0;
                                    foreach ($comp_data['athletes'] as $athlete) {
                                        $total_amount += $athlete['biaya_pendaftaran'] ?? 0;
                                    }
                                    ?>
                                    <span class="total-cost">Total: <?php echo formatRupiahCurrency($total_amount); ?></span>
                                </div>
                            </div>
                            
                            <div class="athletes-table-container">
                                <table class="athletes-table">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Atlet</th>
                                            <th>Kategori</th>
                                            <th>Jenis Kompetisi</th>
                                            <th>Biaya</th>
                                            <th>Status Bayar</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 1; foreach ($comp_data['athletes'] as $athlete): ?>
                                            <tr class="athlete-row">
                                                <td><?php echo $no++; ?></td>
                                                <td>
                                                    <div class="athlete-name">
                                                        <strong><?php echo htmlspecialchars($athlete['athlete_name']); ?></strong>
                                                        <small class="registration-date">
                                                            Daftar: <?php echo formatDate($athlete['created_at'], 'd/m/Y H:i'); ?>
                                                        </small>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="category-info">
                                                        <?php if ($athlete['category_name']): ?>
                                                            <div class="category-name"><?php echo htmlspecialchars($athlete['category_name']); ?></div>
                                                        <?php endif; ?>
                                                        <?php if ($athlete['age_category_name']): ?>
                                                            <small class="age-category"><?php echo htmlspecialchars($athlete['age_category_name']); ?></small>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php if ($athlete['nama_kompetisi']): ?>
                                                        <span class="competition-type"><?php echo htmlspecialchars($athlete['nama_kompetisi']); ?></span>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <span class="price-amount">
                                                        <?php echo $athlete['biaya_pendaftaran'] ? formatRupiahCurrency($athlete['biaya_pendaftaran']) : 'Gratis'; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="payment-status status-<?php echo $athlete['payment_status']; ?>">
                                                        <?php 
                                                        switch($athlete['payment_status']) {
                                                            case 'paid': echo 'Sudah Bayar'; break;
                                                            case 'verified': echo 'Terverifikasi'; break;
                                                            case 'pending': echo 'Menunggu'; break;
                                                            default: echo 'Belum Bayar';
                                                        }
                                                        ?>
                                                    </span>
                                                    <?php if ($athlete['payment_proof']): ?>
                                                        <div class="payment-proof">
                                                            <a href="../../uploads/<?php echo htmlspecialchars($athlete['payment_proof']); ?>" 
                                                               target="_blank" class="view-proof">
                                                                <i class="fas fa-eye"></i> Lihat Bukti
                                                            </a>
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="action-buttons">
                                                        <!-- Upload Bukti Pembayaran -->
                                                        <?php if ($athlete['payment_status'] !== 'verified'): ?>
                                                            <button class="btn-action btn-upload" 
                                                                    onclick="uploadAthletePayment(<?php echo $athlete['id']; ?>, '<?php echo htmlspecialchars($athlete['athlete_name']); ?>')"
                                                                    title="Upload Bukti Pembayaran">
                                                                <i class="fas fa-upload"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                        
                                                        <!-- Edit Pendaftaran -->
                                                        <?php if ($athlete['payment_status'] === 'pending'): ?>
                                                            <button class="btn-action btn-edit" 
                                                                    onclick="editAthleteRegistration(<?php echo $athlete['id']; ?>, <?php echo $comp_id; ?>, '<?php echo htmlspecialchars($athlete['athlete_name']); ?>')"
                                                                    title="Edit Pendaftaran">
                                                                <i class="fas fa-edit"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                        
                                                        <!-- Hapus Pendaftaran -->
                                                        <?php if ($athlete['payment_status'] === 'pending'): ?>
                                                            <button class="btn-action btn-delete" 
                                                                    onclick="deleteAthleteRegistration(<?php echo $athlete['id']; ?>, '<?php echo htmlspecialchars($athlete['athlete_name']); ?>')"
                                                                    title="Hapus Pendaftaran">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                        
                                                        <!-- Invoice Atlet -->
                                                        <button class="btn-action btn-invoice" 
                                                                onclick="viewAthleteInvoice(<?php echo $athlete['id']; ?>)"
                                                                title="Lihat Invoice">
                                                            <i class="fas fa-file-invoice"></i>
                                                        </button>
                                                        
                                                        <!-- Download Invoice -->
                                                        <button class="btn-action btn-download" 
                                                                onclick="downloadAthleteInvoice(<?php echo $athlete['id']; ?>)"
                                                                title="Download Invoice">
                                                            <i class="fas fa-download"></i>
                                                        </button>
                                                        
                                                        <!-- Print Invoice -->
                                                        <button class="btn-action btn-print" 
                                                                onclick="printAthleteInvoice(<?php echo $athlete['id']; ?>)"
                                                                title="Print Invoice">
                                                            <i class="fas fa-print"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Kontingen Actions Bar -->
                            <div class="kontingen-actions-bar">
                                <div class="kontingen-summary">
                                    <div class="summary-stats">
                                        <?php 
                                        $total_athletes = count($comp_data['athletes']);
                                        $verified_count = 0;
                                        $paid_count = 0;
                                        $pending_count = 0;
                                        
                                        foreach ($comp_data['athletes'] as $athlete) {
                                            switch($athlete['payment_status']) {
                                                case 'verified': $verified_count++; break;
                                                case 'paid': $paid_count++; break;
                                                case 'pending': $pending_count++; break;
                                            }
                                        }
                                        ?>
                                        
                                        <div class="stat-item">
                                            <span class="stat-label">Total Atlet:</span>
                                            <span class="stat-value"><?php echo $total_athletes; ?></span>
                                        </div>
                                        <div class="stat-item">
                                            <span class="stat-label">Terverifikasi:</span>
                                            <span class="stat-value text-success"><?php echo $verified_count; ?></span>
                                        </div>
                                        <div class="stat-item">
                                            <span class="stat-label">Sudah Bayar:</span>
                                            <span class="stat-value text-info"><?php echo $paid_count; ?></span>
                                        </div>
                                        <div class="stat-item">
                                            <span class="stat-label">Menunggu:</span>
                                            <span class="stat-value text-warning"><?php echo $pending_count; ?></span>
                                        </div>
                                        <div class="stat-item total-cost-item">
                                            <span class="stat-label">Total Biaya:</span>
                                            <span class="stat-value total-amount"><?php echo formatRupiahCurrency($total_amount); ?></span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="kontingen-actions">
                                    <button class="btn-kontingen btn-view-invoice" onclick="viewKontingenInvoice(<?php echo $comp_id; ?>)">
                                        <i class="fas fa-file-invoice-dollar"></i> Lihat Invoice Kontingen
                                    </button>
                                    <button class="btn-kontingen btn-download-invoice" onclick="downloadKontingenInvoice(<?php echo $comp_id; ?>)">
                                        <i class="fas fa-download"></i> Download Invoice
                                    </button>
                                    <button class="btn-kontingen btn-print-invoice" onclick="printKontingenInvoice(<?php echo $comp_id; ?>)">
                                        <i class="fas fa-print"></i> Print Invoice
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        </div>

        <!-- Tab Content: Available Competitions -->
        <div id="available-competitions" class="tab-content">
            <?php if (empty($available_competitions)): ?>
                <div class="empty-state">
                    <i class="fas fa-trophy"></i>
                    <p>Tidak Ada Perlombaan Tersedia</p>
                    <small>Saat ini tidak ada perlombaan yang membuka pendaftaran.</small>
                </div>
            <?php else: ?>
                <div class="competitions-grid">
                    <?php foreach ($available_competitions as $competition): ?>
                        <div class="competition-card">
                            <div class="competition-card-header">
                                <h3><?php echo htmlspecialchars($competition['nama_perlombaan']); ?></h3>
                                <span class="status-badge status-<?php echo $competition['current_registration_status']; ?>">
                                    <?php 
                                    switch($competition['current_registration_status']) {
                                        case 'open_regist': echo 'Buka Pendaftaran'; break;
                                        case 'close_regist': echo 'Tutup Pendaftaran'; break;
                                        case 'coming_soon': echo 'Segera Dibuka'; break;
                                        default: echo 'Tidak Aktif';
                                    }
                                    ?>
                                </span>
                            </div>
                            
                            <div class="competition-card-body">
                                <div class="competition-info-item">
                                    <i class="fas fa-calendar"></i>
                                    <span>Tanggal: <?php echo formatDate($competition['tanggal_pelaksanaan']); ?></span>
                                </div>
                                <div class="competition-info-item">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <span>Lokasi: <?php echo htmlspecialchars($competition['lokasi'] ?? 'TBA'); ?></span>
                                </div>
                                <div class="competition-info-item">
                                    <i class="fas fa-calendar-check"></i>
                                    <span>Pendaftaran: <?php echo formatDate($competition['tanggal_open_regist']); ?> - <?php echo formatDate($competition['tanggal_close_regist']); ?></span>
                                </div>
                                <div class="competition-info-item">
                                    <i class="fas fa-users"></i>
                                    <span>Total Pendaftar: <?php echo $competition['total_registrations']; ?> atlet</span>
                                </div>
                                
                                <?php if ($competition['deskripsi']): ?>
                                    <div class="competition-description">
                                        <p><?php echo nl2br(htmlspecialchars($competition['deskripsi'])); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="competition-card-footer">
                                <?php if ($competition['current_registration_status'] === 'open_regist'): ?>
                                    <a href="daftar-perlombaan.php?id=<?php echo $competition['id']; ?>" class="btn-primary">
                                        <i class="fas fa-plus"></i> Daftar Sekarang
                                    </a>
                                <?php else: ?>
                                    <button class="btn-secondary" disabled>
                                        <i class="fas fa-lock"></i> Pendaftaran Ditutup
                                    </button>
                                <?php endif; ?>
                                <button class="btn-secondary" onclick="viewCompetitionDetails(<?php echo $competition['id']; ?>)">
                                    <i class="fas fa-info-circle"></i> Detail
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Tab Content: Matches -->
        <div id="matches" class="tab-content">
            <div class="matches-container">
                <!-- Sub Navigation for Matches -->
                <div class="sub-nav-tabs">
                    <button class="sub-nav-tab active" onclick="showSubTab('brackets', this)">
                        <i class="fas fa-sitemap"></i> Bagan Pertandingan
                    </button>
                    <button class="sub-nav-tab" onclick="showSubTab('schedules', this)">
                        <i class="fas fa-calendar-alt"></i> Jadwal Pertandingan
                    </button>
                    <button class="sub-nav-tab" onclick="showSubTab('scores', this)">
                        <i class="fas fa-star"></i> Penilaian TGR
                    </button>
                    <button class="sub-nav-tab" onclick="showSubTab('medals', this)">
                        <i class="fas fa-medal"></i> Perolehan Medali
                    </button>
                    <button class="sub-nav-tab" onclick="showSubTab('medal-recap', this)">
                        <i class="fas fa-chart-bar"></i> Rekapitulasi Medali
                    </button>
                </div>
                
                <!-- Brackets Sub Tab -->
                <div id="brackets" class="sub-tab-content active">
                    <?php if (empty($brackets_data)): ?>
                        <div class="empty-state">
                            <i class="fas fa-sitemap"></i>
                            <p>Belum Ada Bagan Pertandingan</p>
                            <small>Bagan pertandingan akan ditampilkan setelah admin mengatur pertandingan.</small>
                        </div>
                    <?php else: ?>
                        <div class="brackets-container">
                            <?php 
                            $grouped_brackets = [];
                            foreach ($brackets_data as $bracket) {
                                $key = $bracket['competition_id'] . '_' . $bracket['category_id'] . '_' . $bracket['age_category_id'];
                                if (!isset($grouped_brackets[$key])) {
                                    $grouped_brackets[$key] = [
                                        'info' => $bracket,
                                        'matches' => []
                                    ];
                                }
                                $grouped_brackets[$key]['matches'][] = $bracket;
                            }
                            ?>
                            
                            <?php foreach ($grouped_brackets as $group): ?>
                                <div class="bracket-section">
                                    <div class="bracket-header">
                                        <h3><?php echo htmlspecialchars($group['info']['nama_perlombaan']); ?></h3>
                                        <div class="bracket-category">
                                            <?php if ($group['info']['nama_kategori']): ?>
                                                <span><?php echo htmlspecialchars($group['info']['nama_kategori']); ?></span>
                                            <?php endif; ?>
                                            <?php if ($group['info']['age_category_name']): ?>
                                                <span><?php echo htmlspecialchars($group['info']['age_category_name']); ?></span>
                                            <?php endif; ?>
                                            <?php if ($group['info']['nama_kompetisi']): ?>
                                                <span><?php echo htmlspecialchars($group['info']['nama_kompetisi']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    
                                    <div class="bracket-tree">
                                        <?php 
                                        $rounds = [];
                                        foreach ($group['matches'] as $match) {
                                            $rounds[$match['round_number']][] = $match;
                                        }
                                        ksort($rounds);
                                        ?>
                                        
                                        <?php foreach ($rounds as $round_num => $round_matches): ?>
                                            <div class="bracket-round">
                                                <h4>Round <?php echo $round_num; ?></h4>
                                                <div class="bracket-matches">
                                                    <?php foreach ($round_matches as $match): ?>
                                                        <div class="bracket-match <?php echo $match['status']; ?>">
                                                            <div class="match-participants">
                                                                <div class="participant <?php echo $match['winner_id'] == $match['participant1_id'] ? 'winner' : ''; ?>">
                                                                    <span class="athlete-name"><?php echo htmlspecialchars($match['athlete1_name'] ?? 'TBA'); ?></span>
                                                                    <span class="kontingen-name"><?php echo htmlspecialchars($match['kontingen1_name'] ?? ''); ?></span>
                                                                </div>
                                                                <div class="vs">VS</div>
                                                                <div class="participant <?php echo $match['winner_id'] == $match['participant2_id'] ? 'winner' : ''; ?>">
                                                                    <span class="athlete-name"><?php echo htmlspecialchars($match['athlete2_name'] ?? 'TBA'); ?></span>
                                                                    <span class="kontingen-name"><?php echo htmlspecialchars($match['kontingen2_name'] ?? ''); ?></span>
                                                                </div>
                                                            </div>
                                                            <div class="match-status">
                                                                <span class="status-badge status-<?php echo $match['status']; ?>">
                                                                    <?php 
                                                                    switch($match['status']) {
                                                                        case 'scheduled': echo 'Terjadwal'; break;
                                                                        case 'ongoing': echo 'Berlangsung'; break;
                                                                        case 'completed': echo 'Selesai'; break;
                                                                        case 'cancelled': echo 'Dibatalkan'; break;
                                                                        default: echo 'Menunggu';
                                                                    }
                                                                    ?>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Schedules Sub Tab -->
                <div id="schedules" class="sub-tab-content">
                    <?php if (empty($schedules_data)): ?>
                        <div class="empty-state">
                            <i class="fas fa-calendar-alt"></i>
                            <p>Belum Ada Jadwal Pertandingan</p>
                            <small>Jadwal pertandingan akan ditampilkan setelah admin mengatur jadwal.</small>
                        </div>
                    <?php else: ?>
                        <div class="schedules-container">
                            <div class="schedules-table-container">
                                <table class="schedules-table">
                                    <thead>
                                        <tr>
                                            <th>Tanggal & Waktu</th>
                                            <th>Perlombaan</th>
                                            <th>Arena</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($schedules_data as $schedule): ?>
                                            <tr>
                                                <td>
                                                    <div class="schedule-datetime">
                                                        <div class="schedule-date"><?php echo formatDate($schedule['match_date']); ?></div>
                                                        <div class="schedule-time"><?php echo date('H:i', strtotime($schedule['match_time'])); ?></div>
                                                    </div>
                                                </td>
                                                <td><?php echo htmlspecialchars($schedule['nama_perlombaan']); ?></td>
                                                <td><?php echo htmlspecialchars($schedule['arena'] ?? '-'); ?></td>
                                                <td>
                                                    <span class="status-badge status-<?php echo $schedule['status']; ?>">
                                                        <?php 
                                                        switch($schedule['status']) {
                                                            case 'scheduled': echo 'Terjadwal'; break;
                                                            case 'ongoing': echo 'Berlangsung'; break;
                                                            case 'completed': echo 'Selesai'; break;
                                                            case 'cancelled': echo 'Dibatalkan'; break;
                                                            default: echo 'Menunggu';
                                                        }
                                                        ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Scores Sub Tab -->
                <div id="scores" class="sub-tab-content">
                    <?php if (empty($scores_data)): ?>
                        <div class="empty-state">
                            <i class="fas fa-star"></i>
                            <p>Belum Ada Penilaian TGR</p>
                            <small>Penilaian TGR akan ditampilkan setelah admin menginput nilai.</small>
                        </div>
                    <?php else: ?>
                        <div class="scores-container">
                            <div class="scores-table-container">
                                <table class="scores-table">
                                    <thead>
                                        <tr>
                                            <th>Ranking</th>
                                            <th>Atlet</th>
                                            <th>Kontingen</th>
                                            <th>Total Skor</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $rank = 1; foreach ($scores_data as $score): ?>
                                            <tr>
                                                <td>
                                                    <div class="ranking">
                                                        <?php if ($rank <= 3): ?>
                                                            <i class="fas fa-medal ranking-<?php echo $rank; ?>"></i>
                                                        <?php endif; ?>
                                                        <span><?php echo $rank; ?></span>
                                                    </div>
                                                </td>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($score['athlete_name']); ?></strong>
                                                </td>
                                                <td><?php echo htmlspecialchars($score['nama_kontingen']); ?></td>
                                                <td><span class="total-score"><?php echo number_format($score['total_score'], 2); ?></span></td>
                                            </tr>
                                        <?php $rank++; endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Medals Sub Tab -->
                <div id="medals" class="sub-tab-content">
                    <?php if (empty($medals_data)): ?>
                        <div class="empty-state">
                            <i class="fas fa-medal"></i>
                            <p>Belum Ada Perolehan Medali</p>
                            <small>Perolehan medali akan ditampilkan setelah admin menginput hasil.</small>
                        </div>
                    <?php else: ?>
                        <div class="medals-container">
                            <div class="medals-grid">
                                <?php foreach ($medals_data as $medal): ?>
                                    <div class="medal-card medal-<?php echo $medal['medal_type']; ?>">
                                        <div class="medal-icon">
                                            <i class="fas fa-medal"></i>
                                        </div>
                                        <div class="medal-info">
                                            <h4><?php echo htmlspecialchars($medal['athlete_name']); ?></h4>
                                            <p class="kontingen"><?php echo htmlspecialchars($medal['nama_kontingen']); ?></p>
                                            <p class="competition"><?php echo htmlspecialchars($medal['nama_perlombaan']); ?></p>
                                        </div>
                                        <div class="medal-type">
                                            <?php 
                                            switch($medal['medal_type']) {
                                                case 'gold': echo 'EMAS'; break;
                                                case 'silver': echo 'PERAK'; break;
                                                case 'bronze': echo 'PERUNGGU'; break;
                                            }
                                            ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Medal Recap Sub Tab -->
                <div id="medal-recap" class="sub-tab-content">
                    <?php if (empty($medals_data)): ?>
                        <div class="empty-state">
                            <i class="fas fa-chart-bar"></i>
                            <p>Belum Ada Rekapitulasi Medali</p>
                            <small>Rekapitulasi medali akan ditampilkan setelah ada perolehan medali.</small>
                        </div>
                    <?php else: ?>
                        <?php
                        // Calculate medal recap by kontingen
                        $medal_recap = [];
                        foreach ($medals_data as $medal) {
                            $kontingen = $medal['nama_kontingen'];
                            if (!isset($medal_recap[$kontingen])) {
                                $medal_recap[$kontingen] = [
                                    'gold' => 0,
                                    'silver' => 0,
                                    'bronze' => 0,
                                    'total' => 0
                                ];
                            }
                            $medal_recap[$kontingen][$medal['medal_type']]++;
                            $medal_recap[$kontingen]['total']++;
                        }
                        
                        // Sort by total medals (gold priority)
                        uasort($medal_recap, function($a, $b) {
                            if ($a['gold'] != $b['gold']) return $b['gold'] - $a['gold'];
                            if ($a['silver'] != $b['silver']) return $b['silver'] - $a['silver'];
                            if ($a['bronze'] != $b['bronze']) return $b['bronze'] - $a['bronze'];
                            return $b['total'] - $a['total'];
                        });
                        ?>
                        
                        <div class="medal-recap-container">
                            <div class="medal-recap-table-container">
                                <table class="medal-recap-table">
                                    <thead>
                                        <tr>
                                            <th>Peringkat</th>
                                            <th>Kontingen</th>
                                            <th class="medal-col gold">
                                                <i class="fas fa-medal"></i> Emas
                                            </th>
                                            <th class="medal-col silver">
                                                <i class="fas fa-medal"></i> Perak
                                            </th>
                                            <th class="medal-col bronze">
                                                <i class="fas fa-medal"></i> Perunggu
                                            </th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $rank = 1; foreach ($medal_recap as $kontingen => $medals): ?>
                                            <tr>
                                                <td>
                                                    <div class="ranking">
                                                        <?php if ($rank <= 3): ?>
                                                            <i class="fas fa-trophy ranking-<?php echo $rank; ?>"></i>
                                                        <?php endif; ?>
                                                        <span><?php echo $rank; ?></span>
                                                    </div>
                                                </td>
                                                <td><strong><?php echo htmlspecialchars($kontingen); ?></strong></td>
                                                <td class="medal-count gold"><?php echo $medals['gold']; ?></td>
                                                <td class="medal-count silver"><?php echo $medals['silver']; ?></td>
                                                <td class="medal-count bronze"><?php echo $medals['bronze']; ?></td>
                                                <td><strong><?php echo $medals['total']; ?></strong></td>
                                            </tr>
                                        <?php $rank++; endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Payment Upload Modal -->
    <div id="paymentModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Upload Bukti Pembayaran</h3>
                <span class="close" onclick="closePaymentModal()">&times;</span>
            </div>
            <div class="modal-body">
                <p>Upload bukti pembayaran untuk atlet: <strong id="athleteNameDisplay"></strong></p>
                <form id="paymentForm" enctype="multipart/form-data">
                    <input type="hidden" id="registrationId" name="registration_id">
                    <div class="form-group">
                        <label for="paymentProof">Bukti Pembayaran *</label>
                        <input type="file" id="paymentProof" name="payment_proof" accept="image/*" required>
                        <small class="form-help">Format: JPG, PNG, GIF. Maksimal 5MB.</small>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn-primary">
                            <i class="fas fa-upload"></i> Upload
                        </button>
                        <button type="button" class="btn-secondary" onclick="closePaymentModal()">
                            <i class="fas fa-times"></i> Batal
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Kontingen Payment Upload Modal -->
    <div id="kontingenPaymentModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Upload Bukti Pembayaran Kontingen</h3>
                <span class="close" onclick="closeKontingenPaymentModal()">&times;</span>
            </div>
            <div class="modal-body">
                <p>Upload bukti pembayaran untuk perlombaan: <strong id="kontingenCompetitionName"></strong></p>
                <form id="kontingenPaymentForm" enctype="multipart/form-data">
                    <input type="hidden" id="kontingenCompetitionId" name="competition_id">
                    <div class="form-group">
                        <label for="kontingenPaymentProof">Bukti Pembayaran *</label>
                        <input type="file" id="kontingenPaymentProof" name="payment_proof" accept="image/*" required>
                        <small class="form-help">Format: JPG, PNG, GIF. Maksimal 5MB.</small>
                    </div>
                    <div class="form-group">
                        <label for="kontingenPaymentNote">Catatan Pembayaran</label>
                        <textarea id="kontingenPaymentNote" name="payment_note" rows="3" placeholder="Catatan tambahan (opsional)"></textarea>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn-primary">
                            <i class="fas fa-upload"></i> Upload
                        </button>
                        <button type="button" class="btn-secondary" onclick="closeKontingenPaymentModal()">
                            <i class="fas fa-times"></i> Batal
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Registration Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Edit Pendaftaran</h3>
                <span class="close" onclick="closeEditModal()">&times;</span>
            </div>
            <div class="modal-body">
                <p>Edit pendaftaran untuk atlet: <strong id="editAthleteNameDisplay"></strong></p>
                <form id="editForm">
                    <input type="hidden" id="editRegistrationId" name="registration_id">
                    <input type="hidden" id="editCompetitionId" name="competition_id">
                
                    <div class="form-group">
                        <label for="editAgeCategory">Kategori Umur *</label>
                        <select id="editAgeCategory" name="age_category_id" required onchange="loadCompetitionCategories()">
                            <option value="">Pilih Kategori Umur</option>
                        </select>
                    </div>
                
                    <div class="form-group">
                        <label for="editCategory">Kategori Kompetisi</label>
                        <select id="editCategory" name="category_id">
                            <option value="">Pilih Kategori</option>
                        </select>
                    </div>
                
                    <div class="form-group">
                        <label for="editCompetitionType">Jenis Kompetisi *</label>
                        <select id="editCompetitionType" name="competition_type_id" required>
                            <option value="">Pilih Jenis Kompetisi</option>
                        </select>
                    </div>
                
                    <div class="form-actions">
                        <button type="submit" class="btn-primary">
                            <i class="fas fa-save"></i> Simpan
                        </button>
                        <button type="button" class="btn-secondary" onclick="closeEditModal()">
                            <i class="fas fa-times"></i> Batal
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Konfirmasi Hapus</h3>
                <span class="close" onclick="closeDeleteModal()">&times;</span>
            </div>
            <div class="modal-body">
                <div class="delete-confirmation">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h4>Hapus Pendaftaran?</h4>
                    <p>Apakah Anda yakin ingin menghapus pendaftaran atlet <strong id="deleteAthleteName"></strong>?</p>
                    <p>Tindakan ini tidak dapat dibatalkan.</p>
                
                    <form id="deleteForm">
                        <input type="hidden" id="deleteRegistrationId" name="registration_id">
                    
                        <div class="form-actions">
                            <button type="submit" class="btn-danger">
                                <i class="fas fa-trash"></i> Ya, Hapus
                            </button>
                            <button type="button" class="btn-secondary" onclick="closeDeleteModal()">
                                <i class="fas fa-times"></i> Batal
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript functions -->
    <script>
// Tab switching functions
function showTab(tabId, element) {
    // Hide all tab contents
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active class from all nav tabs
    document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected tab content
    document.getElementById(tabId).classList.add('active');
    
    // Add active class to clicked nav tab
    element.classList.add('active');
}

function showSubTab(tabId, element) {
    // Hide all sub tab contents
    document.querySelectorAll('.sub-tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active class from all sub nav tabs
    document.querySelectorAll('.sub-nav-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected sub tab content
    document.getElementById(tabId).classList.add('active');
    
    // Add active class to clicked sub nav tab
    element.classList.add('active');
}

function viewCompetitionDetails(competitionId) {
    // Open competition details modal or redirect
    window.open('competition-details.php?id=' + competitionId, '_blank');
}

// Invoice functions
function viewAthleteInvoice(registrationId) {
    window.open('generate-invoice.php?type=athlete&registration_id=' + registrationId, '_blank');
}

function downloadAthleteInvoice(registrationId) {
    window.open('generate-invoice.php?type=athlete&registration_id=' + registrationId + '&action=download', '_blank');
}

function printAthleteInvoice(registrationId) {
    window.open('generate-invoice.php?type=athlete&registration_id=' + registrationId + '&action=print', '_blank');
}

function viewKontingenInvoice(competitionId) {
    window.open('generate-invoice.php?type=kontingen&competition_id=' + competitionId, '_blank');
}

function downloadKontingenInvoice(competitionId) {
    window.open('generate-invoice.php?type=kontingen&competition_id=' + competitionId + '&action=download', '_blank');
}

function printKontingenInvoice(competitionId) {
    window.open('generate-invoice.php?type=kontingen&competition_id=' + competitionId + '&action=print', '_blank');
}

// Payment upload functions
function uploadAthletePayment(registrationId, athleteName) {
    document.getElementById('registrationId').value = registrationId;
    document.getElementById('athleteNameDisplay').textContent = athleteName;
    document.getElementById('paymentModal').style.display = 'block';
}

function uploadKontingenPayment(competitionId, competitionName) {
    document.getElementById('kontingenCompetitionId').value = competitionId;
    document.getElementById('kontingenCompetitionName').textContent = competitionName;
    document.getElementById('kontingenPaymentModal').style.display = 'block';
}

function closePaymentModal() {
    document.getElementById('paymentModal').style.display = 'none';
    document.getElementById('paymentForm').reset();
}

function closeKontingenPaymentModal() {
    document.getElementById('kontingenPaymentModal').style.display = 'none';
    document.getElementById('kontingenPaymentForm').reset();
}

// Edit registration functions
function editAthleteRegistration(registrationId, competitionId, athleteName) {
    document.getElementById('editRegistrationId').value = registrationId;
    document.getElementById('editCompetitionId').value = competitionId;
    document.getElementById('editAthleteNameDisplay').textContent = athleteName;
    
    // Load registration data
    fetch('get-registration-data.php?registration_id=' + registrationId)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Load age categories first
                loadAgeCategories(competitionId, data.age_category_id);
                // Then load other data
                setTimeout(() => {
                    if (data.age_category_id) {
                        loadCompetitionCategories(data.category_id);
                    }
                    document.getElementById('editCompetitionType').value = data.competition_type_id || '';
                }, 500);
            } else {
                alert('Error loading registration data: ' + data.message);
            }
        })
        .catch(error => {
            alert('Error loading registration data');
            console.error(error);
        });
    
    document.getElementById('editModal').style.display = 'block';
}

function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
    document.getElementById('editForm').reset();
}

// Delete registration functions
function deleteAthleteRegistration(registrationId, athleteName) {
    document.getElementById('deleteRegistrationId').value = registrationId;
    document.getElementById('deleteAthleteName').textContent = athleteName;
    document.getElementById('deleteModal').style.display = 'block';
}

function closeDeleteModal() {
    document.getElementById('deleteModal').style.display = 'none';
}

// Load competition data functions
function loadAgeCategories(competitionId, selectedId = '') {
    fetch('get-competition-data.php?type=age_categories&competition_id=' + competitionId)
        .then(response => response.json())
        .then(data => {
            const select = document.getElementById('editAgeCategory');
            select.innerHTML = '<option value="">Pilih Kategori Umur</option>';
            data.forEach(item => {
                const option = document.createElement('option');
                option.value = item.id;
                option.textContent = item.nama_kategori;
                if (item.id == selectedId) option.selected = true;
                select.appendChild(option);
            });
            
            // Load competition types
            loadCompetitionTypes(competitionId);
        })
        .catch(error => {
            console.error('Error loading age categories:', error);
        });
}

function loadCompetitionCategories(selectedId = '') {
    const competitionId = document.getElementById('editCompetitionId').value;
    const ageCategoryId = document.getElementById('editAgeCategory').value;
    
    if (competitionId && ageCategoryId) {
        fetch('get-competition-data.php?type=competition_categories&competition_id=' + competitionId + '&age_category_id=' + ageCategoryId)
            .then(response => response.json())
            .then(data => {
                const select = document.getElementById('editCategory');
                select.innerHTML = '<option value="">Pilih Kategori</option>';
                data.forEach(item => {
                    const option = document.createElement('option');
                    option.value = item.id;
                    option.textContent = item.nama_kategori;
                    if (item.id == selectedId) option.selected = true;
                    select.appendChild(option);
                });
            })
            .catch(error => {
                console.error('Error loading competition categories:', error);
            });
    } else {
        document.getElementById('editCategory').innerHTML = '<option value="">Pilih Kategori</option>';
    }
}

function loadCompetitionTypes(competitionId, selectedId = '') {
    fetch('get-competition-data.php?type=competition_types&competition_id=' + competitionId)
        .then(response => response.json())
        .then(data => {
            const select = document.getElementById('editCompetitionType');
            select.innerHTML = '<option value="">Pilih Jenis Kompetisi</option>';
            data.forEach(item => {
                const option = document.createElement('option');
                option.value = item.id;
                option.textContent = item.nama_kompetisi + ' - ' + (item.biaya_pendaftaran ? 'Rp ' + new Intl.NumberFormat('id-ID').format(item.biaya_pendaftaran) : 'Gratis');
                if (item.id == selectedId) option.selected = true;
                select.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error loading competition types:', error);
        });
}

// Form submissions
document.getElementById('paymentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
    submitBtn.disabled = true;
    
    fetch('upload-payment.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(data.message);
            location.reload();
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(error => {
        alert('Terjadi kesalahan saat upload file');
        console.error(error);
    })
    .finally(() => {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    });
});

document.getElementById('kontingenPaymentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
    submitBtn.disabled = true;
    
    fetch('upload-kontingen-payment.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(data.message);
            location.reload();
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(error => {
        alert('Terjadi kesalahan saat upload file');
        console.error(error);
    })
    .finally(() => {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    });
});

document.getElementById('editForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
    submitBtn.disabled = true;
    
    fetch('update-registration.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(data.message);
            location.reload();
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(error => {
        alert('Terjadi kesalahan saat update data');
        console.error(error);
    })
    .finally(() => {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    });
});

document.getElementById('deleteForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Deleting...';
    submitBtn.disabled = true;
    
    fetch('delete-registration.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(data.message);
            location.reload();
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(error => {
        alert('Terjadi kesalahan saat hapus data');
        console.error(error);
    })
    .finally(() => {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    });
});

// Close modals when clicking outside
window.onclick = function(event) {
    const modals = ['paymentModal', 'kontingenPaymentModal', 'editModal', 'deleteModal'];
    modals.forEach(modalId => {
        const modal = document.getElementById(modalId);
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    });
}
</script>
</body>
</html>
