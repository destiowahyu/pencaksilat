<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: ../../index.php');
    exit();
}

// Handle form submissions
if ($_POST) {
    if (isset($_POST['add_kontingen'])) {
        $nama_kontingen = sanitizeInput($_POST['nama_kontingen']);
        $provinsi = sanitizeInput($_POST['provinsi']);
        $kota = sanitizeInput($_POST['kota']);
        
        try {
            $stmt = $pdo->prepare("INSERT INTO kontingen (user_id, nama_kontingen, provinsi, kota) VALUES (?, ?, ?, ?)");
            $stmt->execute([$_SESSION['user_id'], $nama_kontingen, $provinsi, $kota]);
            sendNotification('Kontingen berhasil ditambahkan!', 'success');
        } catch (PDOException $e) {
            sendNotification('Gagal menambahkan kontingen!', 'error');
        }
        header('Location: kontingen.php');
        exit();
    }
    
    if (isset($_POST['edit_kontingen'])) {
        $id = $_POST['kontingen_id'];
        $nama_kontingen = sanitizeInput($_POST['nama_kontingen']);
        $provinsi = sanitizeInput($_POST['provinsi']);
        $kota = sanitizeInput($_POST['kota']);
        
        try {
            $stmt = $pdo->prepare("UPDATE kontingen SET nama_kontingen = ?, provinsi = ?, kota = ? WHERE id = ? AND user_id = ?");
            $stmt->execute([$nama_kontingen, $provinsi, $kota, $id, $_SESSION['user_id']]);
            sendNotification('Data kontingen berhasil diperbarui!', 'success');
        } catch (PDOException $e) {
            sendNotification('Gagal memperbarui data kontingen!', 'error');
        }
        header('Location: kontingen.php');
        exit();
    }
}

// Handle delete
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    try {
        // Check if kontingen has athletes
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM athletes WHERE kontingen_id = ?");
        $stmt->execute([$_GET['id']]);
        $athlete_count = $stmt->fetchColumn();
        
        if ($athlete_count > 0) {
            sendNotification('Tidak dapat menghapus kontingen yang masih memiliki atlet!', 'error');
        } else {
            $stmt = $pdo->prepare("DELETE FROM kontingen WHERE id = ? AND user_id = ?");
            $stmt->execute([$_GET['id'], $_SESSION['user_id']]);
            sendNotification('Kontingen berhasil dihapus!', 'success');
        }
    } catch (PDOException $e) {
        sendNotification('Gagal menghapus kontingen!', 'error');
    }
    header('Location: kontingen.php');
    exit();
}

// Get user's kontingen with athlete count
$stmt = $pdo->prepare("
    SELECT k.*, COUNT(a.id) as total_athletes 
    FROM kontingen k 
    LEFT JOIN athletes a ON k.id = a.kontingen_id 
    WHERE k.user_id = ? 
    GROUP BY k.id 
    ORDER BY k.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$kontingen = $stmt->fetchAll();

$notification = getNotification();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kontingen - User Panel</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php if ($notification): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            showAlert('<?php echo $notification['message']; ?>', '<?php echo $notification['type']; ?>');
        });
    </script>
    <?php endif; ?>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-fist-raised"></i>
                <span>User Panel</span>
            </div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="kontingen.php" class="active"><i class="fas fa-flag"></i> Data Kontingen</a></li>
            <li><a href="data-atlet.php"><i class="fas fa-user-ninja"></i> Data Atlet</a></li>
            <li>
                <a href="#" onclick="toggleSubmenu(this)">
                    <i class="fas fa-trophy"></i> Perlombaan <i class="fas fa-chevron-down" style="margin-left: auto;"></i>
                </a>
                <ul class="sidebar-submenu">
                    <li><a href="perlombaan.php">Daftar Perlombaan</a></li>
                </ul>
            </li>
            <li><a href="akun-saya.php"><i class="fas fa-user-circle"></i> Akun Saya</a></li>
            <li><a href="../../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="page-header">
            <h1 class="page-title">Data Kontingen</h1>
            <p class="page-subtitle">Kelola data kontingen Anda</p>
        </div>

        <!-- Add Kontingen Form -->
        <div class="table-container" style="margin-bottom: 30px;">
            <div class="table-header">
                <h2 class="table-title">Tambah Kontingen Baru</h2>
            </div>
            <form method="POST" style="padding: 30px;">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
                    <div class="form-group">
                        <label for="nama_kontingen">Nama Kontingen</label>
                        <input type="text" id="nama_kontingen" name="nama_kontingen" required placeholder="Contoh: Kontingen Jakarta Pusat">
                    </div>
                    <div class="form-group">
                        <label for="provinsi">Provinsi</label>
                        <select id="provinsi" name="provinsi" required>
                            <option value="">Pilih Provinsi</option>
                            <?php foreach (getProvinces() as $province): ?>
                            <option value="<?php echo $province; ?>"><?php echo $province; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="kota">Kota/Kabupaten</label>
                        <input type="text" id="kota" name="kota" required placeholder="Masukkan nama kota/kabupaten">
                    </div>
                </div>
                <button type="submit" name="add_kontingen" class="btn-primary">
                    <i class="fas fa-plus"></i> Tambah Kontingen
                </button>
            </form>
        </div>

        <!-- Kontingen List -->
        <div class="table-container">
            <div class="table-header">
                <h2 class="table-title">Daftar Kontingen (<?php echo count($kontingen); ?>)</h2>
                <div class="search-box">
                    <input type="text" id="searchKontingen" placeholder="Cari kontingen...">
                </div>
            </div>
            <?php if (empty($kontingen)): ?>
            <div style="padding: 40px; text-align: center; color: #6b7280;">
                <i class="fas fa-flag" style="font-size: 3rem; margin-bottom: 20px; opacity: 0.3;"></i>
                <h3>Belum Ada Data Kontingen</h3>
                <p>Silakan tambahkan data kontingen terlebih dahulu.</p>
            </div>
            <?php else: ?>
            <table class="data-table" id="kontingenTable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Kontingen</th>
                        <th>Provinsi</th>
                        <th>Kota/Kabupaten</th>
                        <th>Total Atlet</th>
                        <th>Terdaftar</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($kontingen as $index => $k): ?>
                    <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td><?php echo htmlspecialchars($k['nama_kontingen']); ?></td>
                        <td><?php echo htmlspecialchars($k['provinsi']); ?></td>
                        <td><?php echo htmlspecialchars($k['kota']); ?></td>
                        <td>
                            <span class="status-badge status-active"><?php echo $k['total_athletes']; ?></span>
                        </td>
                        <td><?php echo date('d M Y', strtotime($k['created_at'])); ?></td>
                        <td>
                            <button class="btn-action btn-edit" onclick="editKontingen(<?php echo $k['id']; ?>)">
                                <i class="fas fa-edit"></i> Ubah
                            </button>
                            <button class="btn-action btn-delete" onclick="deleteKontingen(<?php echo $k['id']; ?>, <?php echo $k['total_athletes']; ?>)">
                                <i class="fas fa-trash"></i> Hapus
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- Edit Kontingen Modal -->
    <div id="editKontingenModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Edit Data Kontingen</h2>
                <span class="close" onclick="closeEditModal()">&times;</span>
            </div>
            <form id="editKontingenForm" method="POST">
                <input type="hidden" id="edit_kontingen_id" name="kontingen_id">
                <div class="form-group">
                    <label for="edit_nama_kontingen">Nama Kontingen</label>
                    <input type="text" id="edit_nama_kontingen" name="nama_kontingen" required>
                </div>
                <div class="form-group">
                    <label for="edit_provinsi">Provinsi</label>
                    <select id="edit_provinsi" name="provinsi" required>
                        <option value="">Pilih Provinsi</option>
                        <?php foreach (getProvinces() as $province): ?>
                        <option value="<?php echo $province; ?>"><?php echo $province; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="edit_kota">Kota/Kabupaten</label>
                    <input type="text" id="edit_kota" name="kota" required>
                </div>
                <button type="submit" name="edit_kontingen" class="btn-primary full-width">
                    <i class="fas fa-save"></i> Simpan Perubahan
                </button>
            </form>
        </div>
    </div>

    <script src="../../assets/js/script.js"></script>
    <script>
        const kontingenData = <?php echo json_encode($kontingen); ?>;
        
        function editKontingen(id) {
            const kontingen = kontingenData.find(k => k.id == id);
            if (kontingen) {
                document.getElementById('editKontingenModal').style.display = 'block';
                document.getElementById('edit_kontingen_id').value = kontingen.id;
                document.getElementById('edit_nama_kontingen').value = kontingen.nama_kontingen;
                document.getElementById('edit_provinsi').value = kontingen.provinsi;
                document.getElementById('edit_kota').value = kontingen.kota;
            }
        }
        
        function deleteKontingen(id, athleteCount) {
            if (athleteCount > 0) {
                showAlert('Tidak dapat menghapus kontingen yang masih memiliki ' + athleteCount + ' atlet!', 'error');
                return;
            }
            
            if (confirmDelete('Apakah Anda yakin ingin menghapus kontingen ini?')) {
                window.location.href = `?action=delete&id=${id}`;
            }
        }
        
        function closeEditModal() {
            document.getElementById('editKontingenModal').style.display = 'none';
        }
        
        // Initialize search
        document.addEventListener('DOMContentLoaded', function() {
            searchTable('searchKontingen', 'kontingenTable');
        });
    </script>
</body>
</html>
