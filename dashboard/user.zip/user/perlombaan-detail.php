<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: ../../index.php');
    exit();
}

$competition_id = $_GET['id'] ?? 0;

// Get competition details
$stmt = $pdo->prepare("SELECT * FROM competitions WHERE id = ? AND status = 'active'");
$stmt->execute([$competition_id]);
$competition = $stmt->fetch();

if (!$competition) {
    header('Location: perlombaan.php');
    exit();
}

// Get documents
$stmt = $pdo->prepare("SELECT * FROM competition_documents WHERE competition_id = ?");
$stmt->execute([$competition_id]);
$documents = $stmt->fetchAll();

// Get contacts
$stmt = $pdo->prepare("SELECT * FROM competition_contacts WHERE competition_id = ?");
$stmt->execute([$competition_id]);
$contacts = $stmt->fetchAll();

// Get age categories
$stmt = $pdo->prepare("SELECT * FROM age_categories WHERE competition_id = ? ORDER BY nama_kategori");
$stmt->execute([$competition_id]);
$age_categories = $stmt->fetchAll();

// Get competition categories
$stmt = $pdo->prepare("
    SELECT cc.*, ac.nama_kategori as age_category_name 
    FROM competition_categories cc 
    LEFT JOIN age_categories ac ON cc.age_category_id = ac.id 
    WHERE cc.competition_id = ?
    ORDER BY cc.nama_kategori
");
$stmt->execute([$competition_id]);
$competition_categories = $stmt->fetchAll();

// Get competition types
$stmt = $pdo->prepare("SELECT * FROM competition_types WHERE competition_id = ? ORDER BY nama_kompetisi");
$stmt->execute([$competition_id]);
$competition_types = $stmt->fetchAll();

// Get payment methods
$stmt = $pdo->prepare("SELECT * FROM payment_methods WHERE status = 'active' ORDER BY nama_bank ASC");
$stmt->execute();
$payment_methods = $stmt->fetchAll();

// Helper function to format currency
function formatRupiahDetail($number) {
    return 'Rp ' . number_format($number, 0, ',', '.');
}

// Determine registration status
$registration_status = $competition['registration_status'] ?? 'coming_soon';
if ($registration_status === 'auto' || empty($registration_status)) {
    $today = date('Y-m-d');
    $open_date = $competition['tanggal_open_regist'];
    $close_date = $competition['tanggal_close_regist'];
    
    if ($open_date && $close_date) {
        if ($today < $open_date) {
            $registration_status = 'coming_soon';
        } elseif ($today >= $open_date && $today <= $close_date) {
            $registration_status = 'open_regist';
        } else {
            $registration_status = 'close_regist';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($competition['nama_perlombaan']); ?> - Detail Perlombaan</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-fist-raised"></i>
                <span>User Panel</span>
            </div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="data-atlet.php"><i class="fas fa-user-ninja"></i> Data Atlet</a></li>
            <li><a href="perlombaan.php" class="active"><i class="fas fa-trophy"></i> Perlombaan</a></li>
            <li><a href="akun-saya.php"><i class="fas fa-user-circle"></i> Akun Saya</a></li>
            <li><a href="../../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="page-header">
            <h1 class="page-title"><?php echo htmlspecialchars($competition['nama_perlombaan']); ?></h1>
            <p class="page-subtitle">Detail informasi perlombaan</p>
            <div class="page-actions">
                <a href="perlombaan.php" class="btn-secondary">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
                <?php if ($registration_status == 'open_regist'): ?>
                    <a href="pendaftaran-form.php?competition_id=<?php echo $competition_id; ?>" class="btn-primary">
                        <i class="fas fa-user-plus"></i> Daftar Sekarang
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Main Content Container -->
        <div class="content-container">
            <div class="competition-detail">
                <!-- Poster Section -->
                <?php if (!empty($competition['poster'])): ?>
                <div class="detail-poster">
                    <img src="../../uploads/<?php echo htmlspecialchars($competition['poster']); ?>" 
                         alt="<?php echo htmlspecialchars($competition['nama_perlombaan']); ?>"
                         class="detail-poster-image">
                </div>
                <?php endif; ?>

                <!-- Basic Information -->
                <div class="detail-section">
                    <h3><i class="fas fa-info-circle"></i> Informasi Umum</h3>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <label>Nama Perlombaan:</label>
                            <span><?php echo htmlspecialchars($competition['nama_perlombaan']); ?></span>
                        </div>
                        <div class="detail-item">
                            <label>Status Pendaftaran:</label>
                            <span class="status-badge status-<?php echo $registration_status; ?>">
                                <?php 
                                switch($registration_status) {
                                    case 'coming_soon': echo 'Segera Hadir'; break;
                                    case 'open_regist': echo 'Buka Pendaftaran'; break;
                                    case 'close_regist': echo 'Tutup Pendaftaran'; break;
                                    default: echo 'Tidak Aktif';
                                }
                                ?>
                            </span>
                        </div>
                        <div class="detail-item">
                            <label>Lokasi:</label>
                            <span><?php echo htmlspecialchars($competition['lokasi'] ?? '-'); ?></span>
                        </div>
                        <?php if (!empty($competition['maps_link'])): ?>
                        <div class="detail-item">
                            <label>Lokasi di Maps:</label>
                            <span>
                                <a href="<?php echo htmlspecialchars($competition['maps_link']); ?>" target="_blank" class="btn-maps">
                                    <i class="fas fa-map-marker-alt"></i> Lihat di Google Maps
                                </a>
                            </span>
                        </div>
                        <?php endif; ?>
                        <div class="detail-item">
                            <label>Tanggal Buka Pendaftaran:</label>
                            <span><?php echo $competition['tanggal_open_regist'] ? date('d M Y', strtotime($competition['tanggal_open_regist'])) : '-'; ?></span>
                        </div>
                        <div class="detail-item">
                            <label>Tanggal Tutup Pendaftaran:</label>
                            <span><?php echo $competition['tanggal_close_regist'] ? date('d M Y', strtotime($competition['tanggal_close_regist'])) : '-'; ?></span>
                        </div>
                        <div class="detail-item">
                            <label>Tanggal Pelaksanaan:</label>
                            <span><?php echo $competition['tanggal_pelaksanaan'] ? date('d M Y', strtotime($competition['tanggal_pelaksanaan'])) : '-'; ?></span>
                        </div>
                        <div class="detail-item full-width">
                            <label>Deskripsi:</label>
                            <span><?php echo nl2br(htmlspecialchars($competition['deskripsi'] ?? '-')); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Payment Methods Section -->
                <?php if (!empty($payment_methods)): ?>
                <div class="detail-section">
                    <h3><i class="fas fa-credit-card"></i> Metode Pembayaran</h3>
                    <div class="payment-methods-grid">
                        <?php foreach ($payment_methods as $payment): ?>
                            <div class="payment-method-card">
                                <div class="payment-header">
                                    <i class="fas fa-university"></i>
                                    <strong><?php echo htmlspecialchars($payment['nama_bank']); ?></strong>
                                </div>
                                <div class="payment-details">
                                    <div class="payment-number"><?php echo htmlspecialchars($payment['nomor_rekening']); ?></div>
                                    <div class="payment-name">a.n. <?php echo htmlspecialchars($payment['pemilik_rekening']); ?></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Documents Section -->
                <?php if (!empty($documents)): ?>
                <div class="detail-section">
                    <h3><i class="fas fa-file-alt"></i> Dokumen</h3>
                    <div class="document-list">
                        <?php foreach ($documents as $doc): ?>
                        <div class="document-item">
                            <i class="fas fa-file-pdf"></i>
                            <span><?php echo htmlspecialchars($doc['nama_dokumen']); ?></span>
                            <a href="../../uploads/<?php echo htmlspecialchars($doc['file_path']); ?>" target="_blank" class="btn-download">
                                <i class="fas fa-download"></i> Download
                            </a>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Age Categories Section -->
                <?php if (!empty($age_categories)): ?>
                <div class="detail-section">
                    <h3><i class="fas fa-users"></i> Kategori Umur</h3>
                    <div class="category-list">
                        <?php foreach ($age_categories as $age_cat): ?>
                        <div class="category-item">
                            <div class="category-header">
                                <strong><?php echo htmlspecialchars($age_cat['nama_kategori']); ?></strong>
                                <span class="age-range"><?php echo $age_cat['usia_min']; ?>-<?php echo $age_cat['usia_max']; ?> tahun</span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Competition Types Section -->
                <?php if (!empty($competition_types)): ?>
                <div class="detail-section">
                    <h3><i class="fas fa-star"></i> Jenis Kompetisi</h3>
                    <div class="competition-type-list">
                        <?php foreach ($competition_types as $comp_type): ?>
                        <div class="competition-type-item">
                            <div class="competition-type-header">
                                <strong><?php echo htmlspecialchars($comp_type['nama_kompetisi']); ?></strong>
                                <?php if ($comp_type['biaya_pendaftaran']): ?>
                                    <span class="price-tag"><?php echo formatRupiahDetail($comp_type['biaya_pendaftaran']); ?></span>
                                <?php else: ?>
                                    <span class="price-tag free">Gratis</span>
                                <?php endif; ?>
                            </div>
                            <?php if (!empty($comp_type['deskripsi'])): ?>
                                <div class="competition-type-description">
                                    <?php echo nl2br(htmlspecialchars($comp_type['deskripsi'])); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Contacts Section -->
                <?php if (!empty($contacts)): ?>
                <div class="detail-section">
                    <h3><i class="fas fa-address-book"></i> Kontak Panitia</h3>
                    <div class="contact-list">
                        <?php foreach ($contacts as $contact): ?>
                        <div class="contact-item">
                            <div class="contact-info">
                                <strong><?php echo htmlspecialchars($contact['nama_kontak']); ?></strong>
                                <?php if (!empty($contact['jabatan'])): ?>
                                    <span class="contact-position"><?php echo htmlspecialchars($contact['jabatan']); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="contact-details">
                                <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $contact['nomor_whatsapp']); ?>" target="_blank" class="contact-whatsapp">
                                    <i class="fab fa-whatsapp"></i> <?php echo htmlspecialchars($contact['nomor_whatsapp']); ?>
                                </a>
                                <?php if (!empty($contact['email'])): ?>
                                    <a href="mailto:<?php echo htmlspecialchars($contact['email']); ?>" class="contact-email">
                                        <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($contact['email']); ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Registration Button -->
                <?php if ($registration_status == 'open_regist'): ?>
                <div class="detail-actions">
                    <a href="pendaftaran-form.php?competition_id=<?php echo $competition_id; ?>" class="btn-register-now">
                        <i class="fas fa-user-plus"></i> Daftar Sekarang
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="../../assets/js/script.js"></script>

    <style>
        /* Content Container */
        .content-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            overflow: hidden;
            margin-bottom: 30px;
            padding: 30px;
        }

        /* Competition Detail Styles */
        .competition-detail {
            max-width: 1200px;
            margin: 0 auto;
        }

        .detail-poster {
            text-align: center;
            margin-bottom: 30px;
        }

        .detail-poster-image {
            max-width: 100%;
            height: auto;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        }

        .detail-section {
            background: white;
            padding: 30px;
            margin-bottom: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .detail-section h3 {
            color: var(--primary-color);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.3rem;
        }

        .detail-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .detail-item {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .detail-item.full-width {
            grid-column: 1 / -1;
        }

        .detail-item label {
            font-weight: 600;
            color: var(--text-light);
            font-size: 0.9rem;
        }

        .detail-item span {
            color: var(--text-color);
            font-size: 1rem;
        }

        .status-badge {
            display: inline-block;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-coming_soon {
            background-color: #fff3cd;
            color: #856404;
        }

        .status-open_regist {
            background-color: #d4edda;
            color: #155724;
        }

        .status-close_regist {
            background-color: #f8d7da;
            color: #721c24;
        }

        .btn-maps {
            background: #4285f4;
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: background 0.3s;
        }

        .btn-maps:hover {
            background: #3367d6;
        }

        /* Payment Methods Styles */
        .payment-methods-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
        }

        .payment-method-card {
            background: #f8fafc;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid var(--primary-color);
        }

        .payment-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 15px;
            color: var(--primary-color);
        }

        .payment-header i {
            font-size: 1.2rem;
        }

        .payment-details {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .payment-number {
            font-size: 1.1rem;
            font-weight: bold;
            color: var(--text-color);
            font-family: monospace;
        }

        .payment-name {
            color: var(--text-light);
            font-size: 0.9rem;
        }

        .document-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .document-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: #f8fafc;
            border-radius: 8px;
            border-left: 4px solid var(--primary-color);
        }

        .document-item i {
            color: #dc2626;
            font-size: 1.5rem;
        }

        .document-item span {
            flex: 1;
            font-weight: 500;
        }

        .btn-download {
            background: var(--primary-color);
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 6px;
            transition: background 0.3s;
        }

        .btn-download:hover {
            background: var(--primary-dark);
        }

        .category-list {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .category-item {
            padding: 20px;
            background: #f8fafc;
            border-radius: 8px;
            border-left: 4px solid var(--primary-color);
        }

        .category-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .category-header strong {
            color: var(--primary-color);
            font-size: 1.1rem;
        }

        .age-range {
            background: var(--primary-color);
            color: white;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .competition-type-list {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .competition-type-item {
            padding: 20px;
            background: #f8fafc;
            border-radius: 8px;
            border-left: 4px solid var(--success-color);
        }

        .competition-type-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .competition-type-header strong {
            color: var(--success-color);
            font-size: 1.1rem;
        }

        .price-tag {
            background: var(--success-color);
            color: white;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .price-tag.free {
            background: #10b981;
        }

        .competition-type-description {
            color: var(--text-light);
            line-height: 1.5;
        }

        .contact-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .contact-item {
            padding: 20px;
            background: #f8fafc;
            border-radius: 8px;
            border-left: 4px solid var(--primary-color);
        }

        .contact-info {
            margin-bottom: 15px;
        }

        .contact-info strong {
            color: var(--primary-color);
            font-size: 1.1rem;
            display: block;
            margin-bottom: 5px;
        }

        .contact-position {
            color: var(--text-light);
            font-size: 0.9rem;
        }

        .contact-details {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .contact-whatsapp, .contact-email {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text-color);
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.3s;
        }

        .contact-whatsapp:hover {
            color: #25d366;
        }

        .contact-email:hover {
            color: var(--primary-color);
        }

        .detail-actions {
            text-align: center;
            padding: 40px;
        }

        .btn-register-now {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            padding: 16px 32px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 1.1rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: transform 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 12px rgba(var(--primary-color-rgb), 0.3);
        }

        .btn-register-now:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(var(--primary-color-rgb), 0.4);
        }

        @media (max-width: 768px) {
            .detail-grid {
                grid-template-columns: 1fr;
            }

            .category-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }

            .competition-type-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }

            .payment-methods-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</body>
</html>
