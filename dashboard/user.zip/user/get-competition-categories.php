<?php
session_start();
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$competition_type_id = $_POST['competition_type_id'] ?? 0;
$age_category_id = $_POST['age_category_id'] ?? 0;

try {
    // Get competition categories based on competition type and age category
    $stmt = $pdo->prepare("
        SELECT cc.* 
        FROM competition_categories cc
        WHERE cc.competition_type_id = ? 
        AND cc.age_category_id = ? 
        AND cc.status = 'active'
        ORDER BY cc.nama_kategori
    ");
    $stmt->execute([$competition_type_id, $age_category_id]);
    $categories = $stmt->fetchAll();
    
    echo json_encode($categories);
    
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
