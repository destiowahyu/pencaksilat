<?php
session_start();
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

try {
    $registration_id = $_POST['registration_id'];
    $competition_id = $_POST['competition_id'];
    $age_category_id = $_POST['age_category_id'];
    $category_id = $_POST['category_id'] ?? null;
    $competition_type_id = $_POST['competition_type_id'];
    
    // Verify ownership and that payment is still pending
    $stmt = $pdo->prepare("
        SELECT r.* FROM registrations r 
        JOIN athletes a ON r.athlete_id = a.id 
        WHERE r.id = ? AND a.user_id = ? AND r.payment_status = 'pending'
    ");
    $stmt->execute([$registration_id, $_SESSION['user_id']]);
    $registration = $stmt->fetch();
    
    if (!$registration) {
        echo json_encode(['success' => false, 'message' => 'Registration not found or cannot be edited']);
        exit();
    }
    
    // Update registration
    $stmt = $pdo->prepare("
        UPDATE registrations 
        SET age_category_id = ?, category_id = ?, competition_type_id = ?, updated_at = NOW()
        WHERE id = ?
    ");
    $stmt->execute([$age_category_id, $category_id, $competition_type_id, $registration_id]);
    
    echo json_encode(['success' => true, 'message' => 'Pendaftaran berhasil diperbarui']);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
