<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: ../../index.php');
    exit();
}

$type = $_GET['type'] ?? 'athlete';
$action = $_GET['action'] ?? 'view';

// Function to generate unique invoice code
function generateInvoiceCode($type, $id, $competition_id) {
    $prefix = $type === 'athlete' ? 'ATL' : 'KTG';
    $date = date('Ymd');
    $comp_code = str_pad($competition_id, 3, '0', STR_PAD_LEFT);
    $id_code = str_pad($id, 4, '0', STR_PAD_LEFT);
    $random = strtoupper(substr(md5(uniqid()), 0, 3));
    
    return "INV-{$prefix}-{$date}-{$comp_code}-{$id_code}-{$random}";
}

// Helper function to format currency
function formatRupiah($number) {
    return 'Rp ' . number_format($number, 0, ',', '.');
}

// Helper function to upload file
function uploadFile($file, $uploadDir) {
    $fileName = basename($file['name']);
    $fileTmpPath = $file['tmp_name'];
    $fileType = $file['type'];
    $fileSize = $file['size'];
    $fileError = $file['error'];
    
    $allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
    if (!in_array($fileType, $allowedTypes) || $fileError !== UPLOAD_ERR_OK) {
        return false;
    }
    
    $destinationPath = $uploadDir . $fileName;
    if (move_uploaded_file($fileTmpPath, $destinationPath)) {
        return $fileName;
    }
    
    return false;
}

try {
    if ($type === 'kontingen') {
        // Handle kontingen payment upload
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $competition_id = $_POST['competition_id'];
            $payment_note = $_POST['payment_note'] ?? '';
            
            // Verify user owns athletes in this competition
            $stmt = $pdo->prepare("
                SELECT COUNT(*) FROM registrations r 
                JOIN athletes a ON r.athlete_id = a.id 
                WHERE r.competition_id = ? AND a.user_id = ?
            ");
            $stmt->execute([$competition_id, $_SESSION['user_id']]);
            
            if ($stmt->fetchColumn() == 0) {
                echo json_encode(['success' => false, 'message' => 'No registrations found']);
                exit();
            }
            
            // Upload payment proof
            if (!isset($_FILES['payment_proof']) || $_FILES['payment_proof']['error'] !== UPLOAD_ERR_OK) {
                echo json_encode(['success' => false, 'message' => 'No file uploaded']);
                exit();
            }
            
            $fileName = uploadFile($_FILES['payment_proof'], '../../uploads/');
            if (!$fileName) {
                echo json_encode(['success' => false, 'message' => 'Failed to upload file']);
                exit();
            }
            
            // Update all registrations for this user in this competition
            $stmt = $pdo->prepare("
                UPDATE registrations r 
                JOIN athletes a ON r.athlete_id = a.id 
                SET r.payment_proof = ?, r.payment_status = 'paid', r.payment_date = NOW(), r.payment_note = ?
                WHERE r.competition_id = ? AND a.user_id = ? AND r.payment_status = 'pending'
            ");
            $stmt->execute([$fileName, $payment_note, $competition_id, $_SESSION['user_id']]);
            
            echo json_encode(['success' => true, 'message' => 'Bukti pembayaran kontingen berhasil diupload']);
            exit();
        }
        
        $competition_id = $_GET['competition_id'] ?? null;
        
        if (!$competition_id) {
            die('Competition ID required');
        }
        
        // Get competition and registrations details
        $stmt = $pdo->prepare("
            SELECT c.nama_perlombaan, c.tanggal_pelaksanaan, c.lokasi,
                   k.nama_kontingen, k.provinsi, k.kota,
                   u.nama as user_name, u.email, u.whatsapp, u.alamat
            FROM competitions c
            JOIN registrations r ON c.id = r.competition_id
            JOIN athletes a ON r.athlete_id = a.id
            JOIN kontingen k ON r.kontingen_id = k.id
            JOIN users u ON a.user_id = u.id
            WHERE c.id = ? AND a.user_id = ?
            GROUP BY c.id, k.id, u.id
            LIMIT 1
        ");
        $stmt->execute([$competition_id, $_SESSION['user_id']]);
        $competition_data = $stmt->fetch();
        
        if (!$competition_data) {
            die('Competition data not found');
        }
        
        // Get all registrations for this competition
        $stmt = $pdo->prepare("
            SELECT r.*, a.nama as athlete_name, a.nik, a.jenis_kelamin,
                   cc.nama_kategori as category_name,
                   ac.nama_kategori as age_category_name,
                   ct.nama_kompetisi, ct.biaya_pendaftaran
            FROM registrations r
            JOIN athletes a ON r.athlete_id = a.id
            LEFT JOIN competition_categories cc ON r.category_id = cc.id
            LEFT JOIN age_categories ac ON r.age_category_id = ac.id
            LEFT JOIN competition_types ct ON r.competition_type_id = ct.id
            WHERE r.competition_id = ? AND a.user_id = ?
            ORDER BY a.nama ASC
        ");
        $stmt->execute([$competition_id, $_SESSION['user_id']]);
        $registrations = $stmt->fetchAll();
        
        if (empty($registrations)) {
            die('No registrations found');
        }
        
        $invoice_code = generateInvoiceCode('kontingen', $competition_id, $competition_id);
        $invoice_title = "Invoice Kontingen - " . $competition_data['nama_perlombaan'];
        $invoice_data = $registrations;
        
    } else {
        // Handle individual athlete payment upload
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $registration_id = $_POST['registration_id'];
            
            // Verify ownership
            $stmt = $pdo->prepare("
                SELECT r.* FROM registrations r 
                JOIN athletes a ON r.athlete_id = a.id 
                WHERE r.id = ? AND a.user_id = ?
            ");
            $stmt->execute([$registration_id, $_SESSION['user_id']]);
            $registration = $stmt->fetch();
            
            if (!$registration) {
                echo json_encode(['success' => false, 'message' => 'Registration not found']);
                exit();
            }
            
            // Upload payment proof
            if (!isset($_FILES['payment_proof']) || $_FILES['payment_proof']['error'] !== UPLOAD_ERR_OK) {
                echo json_encode(['success' => false, 'message' => 'No file uploaded']);
                exit();
            }
            
            $fileName = uploadFile($_FILES['payment_proof'], '../../uploads/');
            if (!$fileName) {
                echo json_encode(['success' => false, 'message' => 'Failed to upload file']);
                exit();
            }
            
            // Update registration
            $stmt = $pdo->prepare("
                UPDATE registrations 
                SET payment_proof = ?, payment_status = 'paid', payment_date = NOW() 
                WHERE id = ?
            ");
            $stmt->execute([$fileName, $registration_id]);
            
            echo json_encode(['success' => true, 'message' => 'Bukti pembayaran berhasil diupload']);
            exit();
        }
        
        $registration_id = $_GET['registration_id'] ?? null;
        
        if (!$registration_id) {
            die('Registration ID required');
        }
        
        // Get registration details
        $stmt = $pdo->prepare("
            SELECT r.*, c.nama_perlombaan, c.tanggal_pelaksanaan, c.lokasi,
                   a.nama as athlete_name, a.nik, a.jenis_kelamin, a.tanggal_lahir,
                   k.nama_kontingen, k.provinsi, k.kota,
                   u.nama as user_name, u.email, u.whatsapp, u.alamat,
                   cc.nama_kategori as category_name,
                   ac.nama_kategori as age_category_name,
                   ct.nama_kompetisi, ct.biaya_pendaftaran
            FROM registrations r
            JOIN competitions c ON r.competition_id = c.id
            JOIN athletes a ON r.athlete_id = a.id
            JOIN kontingen k ON r.kontingen_id = k.id
            JOIN users u ON a.user_id = u.id
            LEFT JOIN competition_categories cc ON r.category_id = cc.id
            LEFT JOIN age_categories ac ON r.age_category_id = ac.id
            LEFT JOIN competition_types ct ON r.competition_type_id = ct.id
            WHERE r.id = ? AND a.user_id = ?
            LIMIT 1
        ");
        $stmt->execute([$registration_id, $_SESSION['user_id']]);
        $data = $stmt->fetch();
        
        if (!$data) {
            throw new Exception('Registration not found');
        }
        
        $invoice_code = generateInvoiceCode('athlete', $registration_id, $data['competition_id']);
        $invoice_title = "Invoice Pendaftaran Atlet";
        $invoice_data = [$data];
    }
    
    // Calculate totals
    $total_amount = 0;
    foreach ($invoice_data as $item) {
        $total_amount += $item['biaya_pendaftaran'] ?? 0;
    }
    
} catch (Exception $e) {
    die('Error: ' . $e->getMessage());
}

// Set headers based on action
if ($action === 'download') {
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="invoice_' . date('Y-m-d') . '.pdf"');
} elseif ($action === 'print') {
    // Add print styles
    echo '<style>@media print { .no-print { display: none; } }</style>';
    echo '<script>window.onload = function() { window.print(); }</script>';
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $invoice_title; ?></title>
    <style>
        body {
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #374151;
            background-color: #f8fafc;
        }
        
        .invoice-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .invoice-header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .invoice-header h1 {
            margin: 0 0 10px 0;
            font-size: 1.8rem;
        }
        
        .invoice-number {
            opacity: 0.9;
            font-size: 0.9rem;
        }
        
        .invoice-body {
            padding: 30px;
        }
        
        .invoice-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }
        
        .info-section h3 {
            color: #374151;
            margin: 0 0 15px 0;
            font-size: 1.1rem;
            border-bottom: 2px solid #e5e7eb;
            padding-bottom: 5px;
        }
        
        .info-item {
            display: flex;
            margin-bottom: 8px;
        }
        
        .info-label {
            font-weight: 600;
            color: #6b7280;
            min-width: 120px;
        }
        
        .info-value {
            color: #374151;
        }
        
        .athletes-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        
        .athletes-table th {
            background: #f3f4f6;
            color: #374151;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #e5e7eb;
        }
        
        .athletes-table td {
            padding: 12px;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .athletes-table tr:hover {
            background: #f9fafb;
        }
        
        .total-section {
            background: #f8fafc;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #667eea;
        }
        
        .total-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .total-row.grand-total {
            font-size: 1.2rem;
            font-weight: 700;
            color: #667eea;
            border-top: 2px solid #e5e7eb;
            padding-top: 10px;
            margin-top: 10px;
        }
        
        .payment-info {
            margin-top: 30px;
            padding: 20px;
            background: #fef3c7;
            border-radius: 8px;
            border-left: 4px solid #f59e0b;
        }
        
        .payment-info h4 {
            color: #92400e;
            margin: 0 0 15px 0;
        }
        
        .bank-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .bank-item {
            background: white;
            padding: 15px;
            border-radius: 6px;
            border: 1px solid #fbbf24;
        }
        
        .bank-name {
            font-weight: 600;
            color: #92400e;
            margin-bottom: 5px;
        }
        
        .bank-account {
            font-family: monospace;
            font-size: 1.1rem;
            color: #374151;
            margin-bottom: 3px;
        }
        
        .bank-owner {
            font-size: 0.9rem;
            color: #6b7280;
        }
        
        .footer {
            text-align: center;
            padding: 20px;
            color: #6b7280;
            font-size: 0.9rem;
            border-top: 1px solid #e5e7eb;
        }
        
        .no-print {
            margin: 20px 0;
            text-align: center;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin: 0 5px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 600;
        }
        
        .btn-primary {
            background: #667eea;
            color: white;
        }
        
        .btn-secondary {
            background: #6b7280;
            color: white;
        }
        
        @media print {
            body {
                background: white;
                padding: 0;
            }
            
            .invoice-container {
                box-shadow: none;
                border-radius: 0;
            }
            
            .no-print {
                display: none;
            }
        }
        
        @media (max-width: 768px) {
            .invoice-info {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            
            .bank-info {
                grid-template-columns: 1fr;
            }
            
            .athletes-table {
                font-size: 0.9rem;
            }
            
            .athletes-table th,
            .athletes-table td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="invoice-container">
        <div class="invoice-header">
            <h1><?php echo $invoice_title; ?></h1>
            <div class="invoice-number">
                Invoice #INV-<?php echo date('Y'); ?>-<?php echo str_pad($invoice_data[0]['id'], 6, '0', STR_PAD_LEFT); ?>
            </div>
        </div>
        
        <div class="invoice-body">
            <div class="invoice-info">
                <div class="info-section">
                    <h3>Informasi Perlombaan</h3>
                    <div class="info-item">
                        <span class="info-label">Nama Perlombaan:</span>
                        <span class="info-value"><?php echo htmlspecialchars($invoice_data[0]['nama_perlombaan']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Tanggal:</span>
                        <span class="info-value"><?php echo date('d M Y', strtotime($invoice_data[0]['tanggal_pelaksanaan'])); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Lokasi:</span>
                        <span class="info-value"><?php echo htmlspecialchars($invoice_data[0]['lokasi'] ?? '-'); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Kontingen:</span>
                        <span class="info-value"><?php echo htmlspecialchars($invoice_data[0]['nama_kontingen']); ?></span>
                    </div>
                </div>
                
                <div class="info-section">
                    <h3>Informasi Pendaftar</h3>
                    <div class="info-item">
                        <span class="info-label">Nama:</span>
                        <span class="info-value"><?php echo htmlspecialchars($invoice_data[0]['user_name']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Email:</span>
                        <span class="info-value"><?php echo htmlspecialchars($invoice_data[0]['email']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">WhatsApp:</span>
                        <span class="info-value"><?php echo htmlspecialchars($invoice_data[0]['whatsapp']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Tanggal Invoice:</span>
                        <span class="info-value"><?php echo date('d M Y'); ?></span>
                    </div>
                </div>
            </div>
            
            <table class="athletes-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Atlet</th>
                        <th>Kategori</th>
                        <th>Jenis Kompetisi</th>
                        <th>Biaya</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach ($invoice_data as $item): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($item['athlete_name']); ?></strong>
                                <br>
                                <small>NIK: <?php echo htmlspecialchars($item['nik']); ?></small>
                            </td>
                            <td>
                                <?php if ($item['category_name']): ?>
                                    <?php echo htmlspecialchars($item['category_name']); ?>
                                    <br>
                                <?php endif; ?>
                                <?php if ($item['age_category_name']): ?>
                                    <small><?php echo htmlspecialchars($item['age_category_name']); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($item['nama_kompetisi'] ?? '-'); ?></td>
                            <td><?php echo formatRupiah($item['biaya_pendaftaran'] ?? 0); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="total-section">
                <div class="total-row">
                    <span>Jumlah Atlet:</span>
                    <span><?php echo count($invoice_data); ?> atlet</span>
                </div>
                <div class="total-row">
                    <span>Subtotal:</span>
                    <span><?php echo formatRupiah($total_amount); ?></span>
                </div>
                <div class="total-row grand-total">
                    <span>Total Pembayaran:</span>
                    <span><?php echo formatRupiah($total_amount); ?></span>
                </div>
            </div>
            
            <?php
            // Get payment methods
            $stmt = $pdo->prepare("SELECT * FROM payment_methods WHERE status = 'active' ORDER BY nama_bank ASC");
            $stmt->execute();
            $payment_methods = $stmt->fetchAll();
            
            if (!empty($payment_methods)):
            ?>
            <div class="payment-info">
                <h4>Informasi Pembayaran</h4>
                <p>Silakan lakukan pembayaran ke salah satu rekening berikut:</p>
                <div class="bank-info">
                    <?php foreach ($payment_methods as $method): ?>
                        <div class="bank-item">
                            <div class="bank-name"><?php echo htmlspecialchars($method['nama_bank']); ?></div>
                            <div class="bank-account"><?php echo htmlspecialchars($method['nomor_rekening']); ?></div>
                            <div class="bank-owner"><?php echo htmlspecialchars($method['pemilik_rekening']); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <p style="margin-top: 15px; font-size: 0.9rem; color: #92400e;">
                    <strong>Catatan:</strong> Setelah melakukan pembayaran, silakan upload bukti pembayaran melalui sistem untuk verifikasi.
                </p>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="footer">
            <p>Invoice ini dibuat secara otomatis oleh sistem pada <?php echo date('d M Y H:i'); ?></p>
            <p>Untuk pertanyaan, silakan hubungi panitia perlombaan.</p>
        </div>
    </div>
    
    <div class="no-print">
        <button class="btn btn-primary" onclick="window.print()">
            <i class="fas fa-print"></i> Print Invoice
        </button>
        <a href="perlombaan.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </div>
</body>
</html>
