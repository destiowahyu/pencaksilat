<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: ../../index.php');
    exit();
}

// Get user's registrations with invoice data
$stmt = $pdo->prepare("
    SELECT r.*, c.nama_perlombaan, c.tanggal_pelaksanaan, a.nama as athlete_name, 
           cc.nama_kategori as category_name, ac.nama_kategori as age_category_name,
           ct.nama_kompetisi, ct.biaya_pendaftaran, k.nama_kontingen,
           u.nama as user_name, u.email, u.whatsapp
    FROM registrations r 
    JOIN competitions c ON r.competition_id = c.id 
    JOIN athletes a ON r.athlete_id = a.id 
    JOIN kontingen k ON r.kontingen_id = k.id
    JOIN users u ON a.user_id = u.id
    LEFT JOIN competition_categories cc ON r.category_id = cc.id
    LEFT JOIN age_categories ac ON r.age_category_id = ac.id
    LEFT JOIN competition_types ct ON r.competition_type_id = ct.id
    WHERE a.user_id = ? AND c.status = 'active'
    ORDER BY c.nama_perlombaan, r.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$registrations = $stmt->fetchAll();

// Group registrations by competition
$competitions = [];
foreach ($registrations as $reg) {
    $comp_id = $reg['competition_id'];
    if (!isset($competitions[$comp_id])) {
        $competitions[$comp_id] = [
            'info' => $reg,
            'athletes' => []
        ];
    }
    $competitions[$comp_id]['athletes'][] = $reg;
}

// Helper function to format currency
function formatRupiah($number) {
    return 'Rp ' . number_format($number, 0, ',', '.');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informasi Pendaftaran - User Panel</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-fist-raised"></i>
                <span>User Panel</span>
            </div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="data-atlet.php"><i class="fas fa-user-ninja"></i> Data Atlet</a></li>
            <li>
                <a href="#" onclick="toggleSubmenu(this)" class="active">
                    <i class="fas fa-trophy"></i> Perlombaan <i class="fas fa-chevron-down" style="margin-left: auto;"></i>
                </a>
                <ul class="sidebar-submenu active">
                    <li><a href="perlombaan.php">Daftar Perlombaan</a></li>
                    <li><a href="pendaftaran-saya.php">Pendaftaran Saya</a></li>
                    <li><a href="informasi-pendaftaran.php" class="active">Informasi Pendaftaran</a></li>
                </ul>
            </li>
            <li><a href="akun-saya.php"><i class="fas fa-user-circle"></i> Akun Saya</a></li>
            <li><a href="../../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="page-header">
            <h1 class="page-title">Informasi Pendaftaran</h1>
            <p class="page-subtitle">Invoice dan informasi pembayaran pendaftaran</p>
        </div>

        <?php if (empty($competitions)): ?>
            <div class="empty-state">
                <i class="fas fa-file-invoice"></i>
                <p>Belum Ada Data Pendaftaran</p>
                <small>Anda belum memiliki data pendaftaran untuk ditampilkan.</small>
                <div style="margin-top: 20px;">
                    <a href="perlombaan.php" class="btn-primary">
                        <i class="fas fa-trophy"></i> Lihat Perlombaan
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="invoice-container">
                <?php foreach ($competitions as $comp_id => $comp_data): ?>
                    <div class="competition-invoice-card">
                        <div class="competition-header">
                            <div class="competition-info">
                                <h3><?php echo htmlspecialchars($comp_data['info']['nama_perlombaan']); ?></h3>
                                <div class="competition-meta">
                                    <span class="competition-date">
                                        <i class="fas fa-calendar"></i>
                                        <?php echo date('d M Y', strtotime($comp_data['info']['tanggal_pelaksanaan'])); ?>
                                    </span>
                                    <span class="kontingen-name">
                                        <i class="fas fa-flag"></i>
                                        <?php echo htmlspecialchars($comp_data['info']['nama_kontingen']); ?>
                                    </span>
                                </div>
                            </div>
                            <div class="invoice-actions">
                                <button class="btn-invoice btn-kontingen" onclick="generateKontingenInvoice(<?php echo $comp_id; ?>)">
                                    <i class="fas fa-file-invoice-dollar"></i> Invoice Kontingen
                                </button>
                            </div>
                        </div>

                        <div class="athletes-invoice-list">
                            <h4><i class="fas fa-users"></i> Daftar Atlet (<?php echo count($comp_data['athletes']); ?> atlet)</h4>
                            
                            <div class="invoice-summary">
                                <?php 
                                $total_cost = 0;
                                $total_paid = 0;
                                $total_pending = 0;
                                $total_verified = 0;
                                
                                foreach ($comp_data['athletes'] as $athlete) {
                                    $cost = $athlete['biaya_pendaftaran'] ?? 0;
                                    $total_cost += $cost;
                                    
                                    switch($athlete['payment_status']) {
                                        case 'paid': $total_paid++; break;
                                        case 'verified': $total_verified++; break;
                                        case 'pending': $total_pending++; break;
                                    }
                                }
                                ?>
                                
                                <div class="summary-grid">
                                    <div class="summary-item">
                                        <span class="summary-label">Total Biaya:</span>
                                        <span class="summary-value total-cost"><?php echo formatRupiah($total_cost); ?></span>
                                    </div>
                                    <div class="summary-item">
                                        <span class="summary-label">Total Atlet:</span>
                                        <span class="summary-value"><?php echo count($comp_data['athletes']); ?> atlet</span>
                                    </div>
                                    <div class="summary-item">
                                        <span class="summary-label">Terverifikasi:</span>
                                        <span class="summary-value text-success"><?php echo $total_verified; ?> atlet</span>
                                    </div>
                                    <div class="summary-item">
                                        <span class="summary-label">Menunggu:</span>
                                        <span class="summary-value text-warning"><?php echo $total_pending; ?> atlet</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="athletes-invoice-grid">
                                <?php foreach ($comp_data['athletes'] as $athlete): ?>
                                    <div class="athlete-invoice-card">
                                        <div class="athlete-invoice-header">
                                            <div class="athlete-info">
                                                <strong><?php echo htmlspecialchars($athlete['athlete_name']); ?></strong>
                                                <span class="payment-status status-<?php echo $athlete['payment_status']; ?>">
                                                    <?php 
                                                    switch($athlete['payment_status']) {
                                                        case 'paid': echo 'Sudah Bayar'; break;
                                                        case 'verified': echo 'Terverifikasi'; break;
                                                        case 'pending': echo 'Menunggu'; break;
                                                        default: echo 'Belum Bayar';
                                                    }
                                                    ?>
                                                </span>
                                            </div>
                                            <div class="athlete-cost">
                                                <?php echo $athlete['biaya_pendaftaran'] ? formatRupiah($athlete['biaya_pendaftaran']) : 'Gratis'; ?>
                                            </div>
                                        </div>
                                        
                                        <div class="athlete-invoice-details">
                                            <?php if ($athlete['category_name']): ?>
                                                <div class="detail-row">
                                                    <span class="detail-label">Kategori:</span>
                                                    <span><?php echo htmlspecialchars($athlete['category_name']); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <?php if ($athlete['age_category_name']): ?>
                                                <div class="detail-row">
                                                    <span class="detail-label">Kategori Umur:</span>
                                                    <span><?php echo htmlspecialchars($athlete['age_category_name']); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <?php if ($athlete['nama_kompetisi']): ?>
                                                <div class="detail-row">
                                                    <span class="detail-label">Jenis Kompetisi:</span>
                                                    <span><?php echo htmlspecialchars($athlete['nama_kompetisi']); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <div class="detail-row">
                                                <span class="detail-label">Tanggal Daftar:</span>
                                                <span><?php echo date('d M Y H:i', strtotime($athlete['created_at'])); ?></span>
                                            </div>
                                        </div>

                                        <div class="athlete-invoice-actions">
                                            <button class="btn-invoice btn-athlete" onclick="generateAthleteInvoice(<?php echo $athlete['id']; ?>)">
                                                <i class="fas fa-file-invoice"></i> Invoice Atlet
                                            </button>
                                            <button class="btn-print" onclick="printAthleteInvoice(<?php echo $athlete['id']; ?>)">
                                                <i class="fas fa-print"></i> Print
                                            </button>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <!-- Kontingen Summary -->
                        <div class="kontingen-summary">
                            <h4><i class="fas fa-flag"></i> Ringkasan Kontingen</h4>
                            <div class="kontingen-details">
                                <div class="kontingen-info">
                                    <div class="info-row">
                                        <span class="info-label">Nama Kontingen:</span>
                                        <span><?php echo htmlspecialchars($comp_data['info']['nama_kontingen']); ?></span>
                                    </div>
                                    <div class="info-row">
                                        <span class="info-label">Penanggung Jawab:</span>
                                        <span><?php echo htmlspecialchars($comp_data['info']['user_name']); ?></span>
                                    </div>
                                    <div class="info-row">
                                        <span class="info-label">Email:</span>
                                        <span><?php echo htmlspecialchars($comp_data['info']['email']); ?></span>
                                    </div>
                                    <div class="info-row">
                                        <span class="info-label">WhatsApp:</span>
                                        <span><?php echo htmlspecialchars($comp_data['info']['whatsapp']); ?></span>
                                    </div>
                                </div>
                                <div class="kontingen-actions">
                                    <button class="btn-print-kontingen" onclick="printKontingenInvoice(<?php echo $comp_id; ?>)">
                                        <i class="fas fa-print"></i> Print Invoice Kontingen
                                    </button>
                                    <button class="btn-download" onclick="downloadKontingenInvoice(<?php echo $comp_id; ?>)">
                                        <i class="fas fa-download"></i> Download PDF
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="../../assets/js/script.js"></script>
    <script>
        function generateAthleteInvoice(registrationId) {
            // Open athlete invoice in new window
            window.open(`generate-invoice.php?registration_id=${registrationId}&type=athlete`, '_blank');
        }

        function generateKontingenInvoice(competitionId) {
            // Open kontingen invoice in new window
            window.open(`generate-invoice.php?competition_id=${competitionId}&type=kontingen`, '_blank');
        }

        function printAthleteInvoice(registrationId) {
            // Open print-friendly athlete invoice
            window.open(`generate-invoice.php?registration_id=${registrationId}&type=athlete&print=1`, '_blank');
        }

        function printKontingenInvoice(competitionId) {
            // Open print-friendly kontingen invoice
            window.open(`generate-invoice.php?competition_id=${competitionId}&type=kontingen&print=1`, '_blank');
        }

        function downloadKontingenInvoice(competitionId) {
            // Download PDF invoice
            window.open(`generate-invoice.php?competition_id=${competitionId}&type=kontingen&format=pdf`, '_blank');
        }
    </script>

    <style>
        .invoice-container {
            display: flex;
            flex-direction: column;
            gap: 30px;
        }

        .competition-invoice-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .competition-header {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            padding: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .competition-info h3 {
            margin: 0 0 10px 0;
            font-size: 1.4rem;
        }

        .competition-meta {
            display: flex;
            align-items: center;
            gap: 20px;
            opacity: 0.9;
        }

        .competition-date, .kontingen-name {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 0.9rem;
        }

        .invoice-actions {
            display: flex;
            gap: 10px;
        }

        .btn-invoice {
            padding: 10px 20px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            text-decoration: none;
        }

        .btn-kontingen {
            background: rgba(255,255,255,0.2);
            color: white;
            border: 2px solid rgba(255,255,255,0.3);
        }

        .btn-kontingen:hover {
            background: rgba(255,255,255,0.3);
            border-color: rgba(255,255,255,0.5);
        }

        .athletes-invoice-list {
            padding: 25px;
        }

        .athletes-invoice-list h4 {
            color: var(--primary-color);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.2rem;
        }

        .invoice-summary {
            background: #f8fafc;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            border-left: 4px solid var(--primary-color);
        }

        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        .summary-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 15px;
            background: white;
            border-radius: 6px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .summary-label {
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.9rem;
        }

        .summary-value {
            font-weight: 700;
            font-size: 1rem;
        }

        .total-cost {
            color: var(--primary-color);
            font-size: 1.1rem;
        }

        .text-success { color: #28a745; }
        .text-warning { color: #ffc107; }

        .athletes-invoice-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 20px;
        }

        .athlete-invoice-card {
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 20px;
            background: #fafafa;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .athlete-invoice-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .athlete-invoice-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
        }

        .athlete-info strong {
            color: var(--primary-color);
            font-size: 1.1rem;
            display: block;
            margin-bottom: 5px;
        }

        .athlete-cost {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--success-color);
        }

        .payment-status {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }

        .status-paid {
            background-color: #d1ecf1;
            color: #0c5460;
        }

        .status-verified {
            background-color: #d4edda;
            color: #155724;
        }

        .athlete-invoice-details {
            margin-bottom: 20px;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 0.9rem;
        }

        .detail-label {
            color: var(--text-light);
            font-weight: 600;
        }

        .athlete-invoice-actions {
            display: flex;
            gap: 10px;
        }

        .btn-athlete {
            background: var(--primary-color);
            color: white;
            flex: 1;
        }

        .btn-athlete:hover {
            background: var(--primary-dark);
        }

        .btn-print {
            background: #6c757d;
            color: white;
            padding: 8px 12px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 6px;
            transition: background 0.3s;
        }

        .btn-print:hover {
            background: #5a6268;
        }

        .kontingen-summary {
            background: var(--light-color);
            padding: 25px;
            border-top: 1px solid var(--border-color);
        }

        .kontingen-summary h4 {
            color: var(--primary-color);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.2rem;
        }

        .kontingen-details {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 30px;
            align-items: start;
        }

        .kontingen-info {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .info-row {
            display: flex;
            gap: 15px;
        }

        .info-label {
            color: var(--text-light);
            font-weight: 600;
            min-width: 150px;
        }

        .kontingen-actions {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .btn-print-kontingen, .btn-download {
            padding: 10px 20px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            white-space: nowrap;
        }

        .btn-print-kontingen {
            background: #6c757d;
            color: white;
        }

        .btn-print-kontingen:hover {
            background: #5a6268;
        }

        .btn-download {
            background: var(--success-color);
            color: white;
        }

        .btn-download:hover {
            background: #218838;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-light);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .empty-state p {
            font-size: 1.2rem;
            margin-bottom: 10px;
            color: var(--text-color);
        }

        .empty-state small {
            font-size: 0.9rem;
        }

        @media (max-width: 768px) {
            .competition-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .competition-meta {
                flex-direction: column;
                align-items: flex-start;
                gap: 8px;
            }

            .invoice-actions {
                width: 100%;
            }

            .btn-kontingen {
                width: 100%;
                justify-content: center;
            }

            .summary-grid {
                grid-template-columns: 1fr;
            }

            .athletes-invoice-grid {
                grid-template-columns: 1fr;
            }

            .athlete-invoice-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }

            .athlete-invoice-actions {
                flex-direction: column;
            }

            .kontingen-details {
                grid-template-columns: 1fr;
                gap: 20px;
            }

            .kontingen-actions {
                flex-direction: row;
            }

            .info-row {
                flex-direction: column;
                gap: 5px;
            }

            .info-label {
                min-width: auto;
            }
        }
    </style>
</body>
</html>
