<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: ../../index.php');
    exit();
}

// Get user's kontingen
$stmt = $pdo->prepare("SELECT * FROM kontingen WHERE user_id = ? ORDER BY created_at ASC");
$stmt->execute([$_SESSION['user_id']]);
$user_kontingen = $stmt->fetchAll();

// Handle form submissions
if ($_POST) {
    if (isset($_POST['add_athlete'])) {
        $nama = sanitizeInput($_POST['nama']);
        $nik = sanitizeInput($_POST['nik']);
        $jenis_kelamin = $_POST['jenis_kelamin'];
        $tanggal_lahir = $_POST['tanggal_lahir'];
        $tempat_lahir = sanitizeInput($_POST['tempat_lahir']);
        $nama_sekolah = sanitizeInput($_POST['nama_sekolah']);
        $berat_badan = $_POST['berat_badan'];
        $tinggi_badan = $_POST['tinggi_badan'];
        $kontingen_id = $_POST['kontingen_id']; // TAMBAHAN BARU
        
        // Validate kontingen ownership
        $stmt = $pdo->prepare("SELECT id FROM kontingen WHERE id = ? AND user_id = ?");
        $stmt->execute([$kontingen_id, $_SESSION['user_id']]);
        if (!$stmt->fetch()) {
            sendNotification('Kontingen tidak valid!', 'error');
            header('Location: data-atlet.php');
            exit();
        }
        
        // Handle photo upload
        $foto = null;
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
            $foto = uploadFile($_FILES['foto'], 'uploads/athletes/');
        }
        
        try {
            $stmt = $pdo->prepare("
                INSERT INTO athletes (user_id, kontingen_id, nama, nik, jenis_kelamin, tanggal_lahir, tempat_lahir, nama_sekolah, berat_badan, tinggi_badan, foto) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$_SESSION['user_id'], $kontingen_id, $nama, $nik, $jenis_kelamin, $tanggal_lahir, $tempat_lahir, $nama_sekolah, $berat_badan, $tinggi_badan, $foto]);
            sendNotification('Atlet berhasil ditambahkan!', 'success');
        } catch (PDOException $e) {
            sendNotification('Gagal menambahkan atlet: ' . $e->getMessage(), 'error');
        }
        header('Location: data-atlet.php');
        exit();
    }
}

// Handle delete
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    try {
        // Get athlete data first to delete photo
        $stmt = $pdo->prepare("SELECT foto FROM athletes WHERE id = ? AND user_id = ?");
        $stmt->execute([$_GET['id'], $_SESSION['user_id']]);
        $athlete = $stmt->fetch();
        
        if ($athlete && $athlete['foto']) {
            deleteFile('uploads/athletes/' . $athlete['foto']);
        }
        
        $stmt = $pdo->prepare("DELETE FROM athletes WHERE id = ? AND user_id = ?");
        $stmt->execute([$_GET['id'], $_SESSION['user_id']]);
        sendNotification('Atlet berhasil dihapus!', 'success');
    } catch (PDOException $e) {
        sendNotification('Gagal menghapus atlet!', 'error');
    }
    header('Location: data-atlet.php');
    exit();
}

// Get user's athletes with kontingen info
$stmt = $pdo->prepare("
    SELECT a.*, k.nama_kontingen 
    FROM athletes a 
    LEFT JOIN kontingen k ON a.kontingen_id = k.id 
    WHERE a.user_id = ? 
    ORDER BY a.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$athletes = $stmt->fetchAll();

$notification = getNotification();

// Helper function to calculate age (fix for the error)
function calculateAge($birthDate) {
    $today = new DateTime();
    $birth = new DateTime($birthDate);
    return $today->diff($birth)->y;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Atlet - User Panel</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php if ($notification): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            showAlert('<?php echo $notification['message']; ?>', '<?php echo $notification['type']; ?>');
        });
    </script>
    <?php endif; ?>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-fist-raised"></i>
                <span>User Panel</span>
            </div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="data-atlet.php" class="active"><i class="fas fa-user-ninja"></i> Data Atlet</a></li>
            <li>
                <a href="#" onclick="toggleSubmenu(this)">
                    <i class="fas fa-trophy"></i> Perlombaan <i class="fas fa-chevron-down" style="margin-left: auto;"></i>
                </a>
                <ul class="sidebar-submenu">
                    <li><a href="perlombaan.php">Daftar Perlombaan</a></li>
                </ul>
            </li>
            <li><a href="akun-saya.php"><i class="fas fa-user-circle"></i> Akun Saya</a></li>
            <li><a href="../../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="page-header">
            <h1 class="page-title">Data Atlet</h1>
            <p class="page-subtitle">Kelola data atlet Anda</p>
        </div>

        <?php if (empty($user_kontingen)): ?>
        <!-- No Kontingen Warning -->
        <div class="alert alert-warning" style="margin-bottom: 30px;">
            <div style="display: flex; align-items: center; gap: 15px;">
                <i class="fas fa-exclamation-triangle" style="font-size: 2rem; color: #f59e0b;"></i>
                <div>
                    <h3 style="margin: 0; color: #f59e0b;">Belum Ada Kontingen</h3>
                    <p style="margin: 5px 0 0 0;">Anda harus membuat kontingen terlebih dahulu sebelum menambahkan atlet.</p>
                    <a href="kontingen.php" class="btn-primary" style="margin-top: 10px; display: inline-block;">
                        <i class="fas fa-plus"></i> Buat Kontingen
                    </a>
                </div>
            </div>
        </div>
        <?php else: ?>
        <!-- Add Athlete Form -->
        <div class="table-container" style="margin-bottom: 30px;">
            <div class="table-header">
                <h2 class="table-title">Tambah Atlet Baru</h2>
            </div>
            <form method="POST" enctype="multipart/form-data" style="padding: 30px;">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
                    <!-- Pilihan Kontingen -->
                    <div class="form-group">
                        <label for="kontingen_id">Pilih Kontingen <span style="color: red;">*</span></label>
                        <select id="kontingen_id" name="kontingen_id" required>
                            <option value="">Pilih Kontingen</option>
                            <?php foreach ($user_kontingen as $kontingen): ?>
                            <option value="<?php echo $kontingen['id']; ?>">
                                <?php echo htmlspecialchars($kontingen['nama_kontingen']); ?> 
                                (<?php echo htmlspecialchars($kontingen['provinsi']); ?> - <?php echo htmlspecialchars($kontingen['kota']); ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <small style="color: #6b7280;">Pilih kontingen untuk atlet ini</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="foto">Foto Atlet</label>
                        <input type="file" id="foto" name="foto" accept="image/*" onchange="handleFileUpload(this, 'foto-preview')">
                        <div id="foto-preview" style="margin-top: 10px;"></div>
                    </div>
                    <div class="form-group">
                        <label for="nama">Nama Lengkap <span style="color: red;">*</span></label>
                        <input type="text" id="nama" name="nama" required>
                    </div>
                    <div class="form-group">
                        <label for="nik">NIK <span style="color: red;">*</span></label>
                        <input type="text" id="nik" name="nik" required maxlength="16" pattern="[0-9]{16}" title="NIK harus 16 digit angka">
                    </div>
                    <div class="form-group">
                        <label for="jenis_kelamin">Jenis Kelamin <span style="color: red;">*</span></label>
                        <select id="jenis_kelamin" name="jenis_kelamin" required>
                            <option value="">Pilih Jenis Kelamin</option>
                            <option value="L">Laki-laki</option>
                            <option value="P">Perempuan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="tanggal_lahir">Tanggal Lahir <span style="color: red;">*</span></label>
                        <input type="date" id="tanggal_lahir" name="tanggal_lahir" required>
                    </div>
                    <div class="form-group">
                        <label for="tempat_lahir">Tempat Lahir <span style="color: red;">*</span></label>
                        <input type="text" id="tempat_lahir" name="tempat_lahir" required>
                    </div>
                    <div class="form-group">
                        <label for="nama_sekolah">Nama Sekolah/Instansi <span style="color: red;">*</span></label>
                        <input type="text" id="nama_sekolah" name="nama_sekolah" required>
                    </div>
                    <div class="form-group">
                        <label for="berat_badan">Berat Badan (kg) <span style="color: red;">*</span></label>
                        <input type="number" id="berat_badan" name="berat_badan" step="0.1" min="1" max="200" required>
                    </div>
                    <div class="form-group">
                        <label for="tinggi_badan">Tinggi Badan (cm) <span style="color: red;">*</span></label>
                        <input type="number" id="tinggi_badan" name="tinggi_badan" step="0.1" min="50" max="250" required>
                    </div>
                </div>
                <div style="margin-top: 20px;">
                    <button type="submit" name="add_athlete" class="btn-primary">
                        <i class="fas fa-plus"></i> Tambah Atlet
                    </button>
                    <button type="reset" class="btn-secondary" style="margin-left: 10px;">
                        <i class="fas fa-undo"></i> Reset Form
                    </button>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <!-- Athletes List -->
        <div class="table-container">
            <div class="table-header">
                <h2 class="table-title">Daftar Atlet (<?php echo count($athletes); ?>)</h2>
                <div class="table-actions">
                    <div class="search-box">
                        <input type="text" id="searchAthlete" placeholder="Cari atlet...">
                    </div>
                    <button class="btn-add" onclick="exportAthletes()">
                        <i class="fas fa-download"></i> Export Excel
                    </button>
                    <button class="btn-add" onclick="showImportModal()">
                        <i class="fas fa-upload"></i> Import Excel
                    </button>
                </div>
            </div>
            <?php if (empty($athletes)): ?>
            <div style="padding: 40px; text-align: center; color: #6b7280;">
                <i class="fas fa-user-ninja" style="font-size: 3rem; margin-bottom: 20px; opacity: 0.3;"></i>
                <h3>Belum Ada Data Atlet</h3>
                <p>Silakan tambahkan data atlet terlebih dahulu.</p>
            </div>
            <?php else: ?>
            <table class="data-table" id="athleteTable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Foto</th>
                        <th>Nama</th>
                        <th>Kontingen</th>
                        <th>NIK</th>
                        <th>JK</th>
                        <th>Tanggal Lahir</th>
                        <th>Tempat Lahir</th>
                        <th>Sekolah/Instansi</th>
                        <th>BB (kg)</th>
                        <th>TB (cm)</th>
                        <th>Umur</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($athletes as $index => $athlete): ?>
                    <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td>
                            <?php if ($athlete['foto']): ?>
                                <img src="../../uploads/athletes/<?php echo $athlete['foto']; ?>" 
                                     alt="<?php echo htmlspecialchars($athlete['nama']); ?>" 
                                     style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;">
                            <?php else: ?>
                                <div style="width: 40px; height: 40px; border-radius: 50%; background: #e5e7eb; display: flex; align-items: center; justify-content: center;">
                                    <i class="fas fa-user" style="color: #9ca3af;"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($athlete['nama']); ?></td>
                        <td>
                            <?php if ($athlete['nama_kontingen']): ?>
                                <span class="badge badge-primary"><?php echo htmlspecialchars($athlete['nama_kontingen']); ?></span>
                            <?php else: ?>
                                <span class="badge badge-warning">Tidak Ada</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($athlete['nik']); ?></td>
                        <td><?php echo $athlete['jenis_kelamin']; ?></td>
                        <td><?php echo date('d M Y', strtotime($athlete['tanggal_lahir'])); ?></td>
                        <td><?php echo htmlspecialchars($athlete['tempat_lahir']); ?></td>
                        <td><?php echo htmlspecialchars($athlete['nama_sekolah']); ?></td>
                        <td><?php echo $athlete['berat_badan']; ?></td>
                        <td><?php echo $athlete['tinggi_badan']; ?></td>
                        <td><?php echo calculateAge($athlete['tanggal_lahir']); ?> tahun</td>
                        <td>
                            <button class="btn-action btn-edit" onclick="editAthlete(<?php echo $athlete['id']; ?>)">
                                <i class="fas fa-edit"></i> Ubah
                            </button>
                            <button class="btn-action btn-delete" onclick="deleteAthlete(<?php echo $athlete['id']; ?>)">
                                <i class="fas fa-trash"></i> Hapus
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- Import Modal -->
    <div id="importModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Import Data Atlet</h2>
                <span class="close" onclick="closeImportModal()">&times;</span>
            </div>
            <div style="padding: 30px;">
                <div class="info-section">
                    <h3><i class="fas fa-info-circle"></i> Template Excel</h3>
                    <p>Download template Excel terlebih dahulu, isi data sesuai format, kemudian upload kembali.</p>
                    <button class="btn-secondary" onclick="downloadTemplate()">
                        <i class="fas fa-download"></i> Download Template
                    </button>
                </div>
                
                <div class="info-section">
                    <h3><i class="fas fa-upload"></i> Upload File Excel</h3>
                    <form method="POST" enctype="multipart/form-data">
                        <div class="file-upload">
                            <input type="file" id="excel_file" name="excel_file" accept=".xlsx,.xls" style="display: none;">
                            <label for="excel_file" class="file-upload-label">
                                <i class="fas fa-cloud-upload-alt" style="font-size: 2rem; margin-bottom: 10px;"></i>
                                <p>Klik untuk pilih file Excel</p>
                                <small>Format: .xlsx atau .xls</small>
                            </label>
                        </div>
                        <button type="submit" name="import_athletes" class="btn-primary full-width" style="margin-top: 20px;">
                            <i class="fas fa-upload"></i> Import Data
                        </button>
                    </form>
                </div>
                
                <div class="info-section">
                    <h3><i class="fas fa-list"></i> Format Data</h3>
                    <p>Pastikan data Excel memiliki kolom berikut (sesuai urutan):</p>
                    <ol>
                        <li>Nama Kontingen</li>
                        <li>Nama Lengkap</li>
                        <li>NIK</li>
                        <li>Jenis Kelamin (L/P)</li>
                        <li>Tanggal Lahir (YYYY-MM-DD)</li>
                        <li>Tempat Lahir</li>
                        <li>Nama Sekolah/Instansi</li>
                        <li>Berat Badan (kg)</li>
                        <li>Tinggi Badan (cm)</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <script src="../../assets/js/script.js"></script>
    <script>
        function editAthlete(id) {
            // Implementation for edit athlete
            showAlert('Fitur edit akan segera tersedia', 'info');
        }
        
        function deleteAthlete(id) {
            if (confirmDelete('Apakah Anda yakin ingin menghapus atlet ini?')) {
                window.location.href = `?action=delete&id=${id}`;
            }
        }
        
        function exportAthletes() {
            exportToExcel('athleteTable', 'data_atlet_' + new Date().toISOString().slice(0,10));
        }
        
        function showImportModal() {
            document.getElementById('importModal').style.display = 'block';
        }
        
        function closeImportModal() {
            document.getElementById('importModal').style.display = 'none';
        }
        
        function downloadTemplate() {
            // Create template data
            const templateData = [
                ['Nama Kontingen', 'Nama Lengkap', 'NIK', 'Jenis Kelamin', 'Tanggal Lahir', 'Tempat Lahir', 'Nama Sekolah/Instansi', 'Berat Badan', 'Tinggi Badan'],
                ['Kontingen Jakarta', 'Ahmad Rizki', '3171234567890001', 'L', '2005-03-15', 'Jakarta', 'SMA Negeri 1 Jakarta', '65.5', '170.0'],
                ['Kontingen Jakarta', 'Siti Aminah', '3171234567890002', 'P', '2006-07-20', 'Jakarta', 'SMA Negeri 2 Jakarta', '55.0', '160.0']
            ];
            
            // Convert to CSV and download
            const csv = templateData.map(row => row.join(',')).join('\n');
            const blob = new Blob([csv], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'template_data_atlet.csv';
            a.click();
            window.URL.revokeObjectURL(url);
        }
        
        // Initialize search
        document.addEventListener('DOMContentLoaded', function() {
            searchTable('searchAthlete', 'athleteTable');
        });
    </script>

    <style>
        .info-section {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .info-section:last-child {
            border-bottom: none;
        }
        
        .info-section h3 {
            color: var(--primary-color);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .info-section ol {
            margin-left: 20px;
        }
        
        .info-section ol li {
            margin-bottom: 5px;
        }
        
        .alert {
            padding: 20px;
            border-radius: 8px;
            border: 1px solid;
        }
        
        .alert-warning {
            background-color: #fef3c7;
            border-color: #f59e0b;
            color: #92400e;
        }
        
        .badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .badge-primary {
            background-color: #dbeafe;
            color: #1e40af;
        }
        
        .badge-warning {
            background-color: #fef3c7;
            color: #92400e;
        }
    </style>
</body>
</html>
