<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: ../../index.php');
    exit();
}

// Handle delete registration
if ($_POST && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $registration_id = $_POST['registration_id'];
    
    try {
        // Verify ownership
        $stmt = $pdo->prepare("
            SELECT r.* FROM registrations r 
            JOIN athletes a ON r.athlete_id = a.id 
            WHERE r.id = ? AND a.user_id = ?
        ");
        $stmt->execute([$registration_id, $_SESSION['user_id']]);
        $registration = $stmt->fetch();
        
        if ($registration) {
            $stmt = $pdo->prepare("DELETE FROM registrations WHERE id = ?");
            $stmt->execute([$registration_id]);
            
            $success_message = "Pendaftaran berhasil dihapus!";
        } else {
            $error_message = "Pendaftaran tidak ditemukan atau Anda tidak memiliki akses.";
        }
    } catch (Exception $e) {
        $error_message = "Gagal menghapus pendaftaran: " . $e->getMessage();
    }
}

// Get user's active registrations
$stmt = $pdo->prepare("
    SELECT r.*, c.nama_perlombaan, c.tanggal_pelaksanaan, a.nama as athlete_name, 
           cc.nama_kategori as category_name, ac.nama_kategori as age_category_name,
           ct.nama_kompetisi, ct.biaya_pendaftaran, k.nama_kontingen,
           CASE 
               WHEN c.registration_status IS NOT NULL THEN c.registration_status
               WHEN CURDATE() < c.tanggal_open_regist THEN 'coming_soon'
               WHEN CURDATE() BETWEEN c.tanggal_open_regist AND c.tanggal_close_regist THEN 'open_regist'
               WHEN CURDATE() > c.tanggal_close_regist THEN 'close_regist'
               ELSE 'coming_soon'
           END as current_registration_status
    FROM registrations r 
    JOIN competitions c ON r.competition_id = c.id 
    JOIN athletes a ON r.athlete_id = a.id 
    JOIN kontingen k ON r.kontingen_id = k.id
    LEFT JOIN competition_categories cc ON r.category_id = cc.id
    LEFT JOIN age_categories ac ON r.age_category_id = ac.id
    LEFT JOIN competition_types ct ON r.competition_type_id = ct.id
    WHERE a.user_id = ? AND c.status = 'active'
    ORDER BY r.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$registrations = $stmt->fetchAll();

// Group registrations by competition
$competitions = [];
foreach ($registrations as $reg) {
    $comp_id = $reg['competition_id'];
    if (!isset($competitions[$comp_id])) {
        $competitions[$comp_id] = [
            'info' => $reg,
            'athletes' => []
        ];
    }
    $competitions[$comp_id]['athletes'][] = $reg;
}

// Helper function to format currency
function formatRupiah($number) {
    return 'Rp ' . number_format($number, 0, ',', '.');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendaftaran Saya - User Panel</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-fist-raised"></i>
                <span>User Panel</span>
            </div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="data-atlet.php"><i class="fas fa-user-ninja"></i> Data Atlet</a></li>
            <li>
                <a href="#" onclick="toggleSubmenu(this)" class="active">
                    <i class="fas fa-trophy"></i> Perlombaan <i class="fas fa-chevron-down" style="margin-left: auto;"></i>
                </a>
                <ul class="sidebar-submenu active">
                    <li><a href="perlombaan.php">Daftar Perlombaan</a></li>
                    <li><a href="pendaftaran-saya.php" class="active">Pendaftaran Saya</a></li>
                    <li><a href="informasi-pendaftaran.php">Informasi Pendaftaran</a></li>
                </ul>
            </li>
            <li><a href="akun-saya.php"><i class="fas fa-user-circle"></i> Akun Saya</a></li>
            <li><a href="../../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="page-header">
            <h1 class="page-title">Pendaftaran Saya</h1>
            <p class="page-subtitle">Kelola pendaftaran atlet dan informasi pembayaran</p>
        </div>

        <?php if (isset($success_message)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
            </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <?php if (empty($competitions)): ?>
            <div class="empty-state">
                <i class="fas fa-user-plus"></i>
                <p>Belum Ada Pendaftaran</p>
                <small>Anda belum mendaftarkan atlet ke perlombaan manapun.</small>
                <div style="margin-top: 20px;">
                    <a href="perlombaan.php" class="btn-primary">
                        <i class="fas fa-trophy"></i> Lihat Perlombaan
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="registrations-container">
                <?php foreach ($competitions as $comp_id => $comp_data): ?>
                    <div class="competition-registration-card">
                        <div class="competition-header">
                            <div class="competition-info">
                                <h3><?php echo htmlspecialchars($comp_data['info']['nama_perlombaan']); ?></h3>
                                <div class="competition-meta">
                                    <span class="competition-date">
                                        <i class="fas fa-calendar"></i>
                                        <?php echo date('d M Y', strtotime($comp_data['info']['tanggal_pelaksanaan'])); ?>
                                    </span>
                                    <span class="status-badge status-<?php echo $comp_data['info']['current_registration_status']; ?>">
                                        <?php 
                                        switch($comp_data['info']['current_registration_status']) {
                                            case 'coming_soon': echo 'Segera Hadir'; break;
                                            case 'open_regist': echo 'Buka Pendaftaran'; break;
                                            case 'close_regist': echo 'Tutup Pendaftaran'; break;
                                            default: echo 'Tidak Aktif';
                                        }
                                        ?>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="athletes-list">
                            <h4><i class="fas fa-users"></i> Daftar Atlet Terdaftar (<?php echo count($comp_data['athletes']); ?> atlet)</h4>
                            
                            <div class="athletes-grid">
                                <?php foreach ($comp_data['athletes'] as $athlete): ?>
                                    <div class="athlete-registration-card">
                                        <div class="athlete-header">
                                            <strong><?php echo htmlspecialchars($athlete['athlete_name']); ?></strong>
                                            <span class="payment-status status-<?php echo $athlete['payment_status']; ?>">
                                                <?php 
                                                switch($athlete['payment_status']) {
                                                    case 'paid': echo 'Sudah Bayar'; break;
                                                    case 'verified': echo 'Terverifikasi'; break;
                                                    case 'pending': echo 'Menunggu'; break;
                                                    default: echo 'Belum Bayar';
                                                }
                                                ?>
                                            </span>
                                        </div>
                                        
                                        <div class="athlete-details">
                                            <?php if ($athlete['category_name']): ?>
                                                <div class="detail-item">
                                                    <span class="detail-label">Kategori:</span>
                                                    <span><?php echo htmlspecialchars($athlete['category_name']); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <?php if ($athlete['age_category_name']): ?>
                                                <div class="detail-item">
                                                    <span class="detail-label">Kategori Umur:</span>
                                                    <span><?php echo htmlspecialchars($athlete['age_category_name']); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <?php if ($athlete['nama_kompetisi']): ?>
                                                <div class="detail-item">
                                                    <span class="detail-label">Jenis Kompetisi:</span>
                                                    <span><?php echo htmlspecialchars($athlete['nama_kompetisi']); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <div class="detail-item">
                                                <span class="detail-label">Biaya:</span>
                                                <span class="price-amount">
                                                    <?php echo $athlete['biaya_pendaftaran'] ? formatRupiah($athlete['biaya_pendaftaran']) : 'Gratis'; ?>
                                                </span>
                                            </div>
                                        </div>

                                        <div class="athlete-actions">
                                            <?php if ($athlete['payment_status'] == 'pending'): ?>
                                                <button class="btn-action btn-pay" onclick="uploadPayment(<?php echo $athlete['id']; ?>)">
                                                    <i class="fas fa-upload"></i> Upload Bukti
                                                </button>
                                                
                                                <button class="btn-action btn-edit" onclick="editRegistration(<?php echo $athlete['id']; ?>, <?php echo $comp_id; ?>)">
                                                    <i class="fas fa-edit"></i> Edit
                                                </button>
                                                
                                                <button class="btn-action btn-delete" onclick="deleteRegistration(<?php echo $athlete['id']; ?>, '<?php echo htmlspecialchars($athlete['athlete_name']); ?>')">
                                                    <i class="fas fa-trash"></i> Hapus
                                                </button>
                                            <?php endif; ?>
                                            
                                            <button class="btn-action btn-invoice" onclick="generateInvoice(<?php echo $athlete['id']; ?>, 'athlete')">
                                                <i class="fas fa-file-invoice"></i> Invoice Atlet
                                            </button>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- Kontingen Invoice Button -->
                            <div class="kontingen-actions">
                                <button class="btn-primary" onclick="generateInvoice(<?php echo $comp_id; ?>, 'kontingen')">
                                    <i class="fas fa-file-invoice-dollar"></i> Invoice Kontingen
                                </button>
                            </div>
                        </div>

                        <!-- Payment Information -->
                        <div class="payment-info">
                            <h4><i class="fas fa-credit-card"></i> Informasi Pembayaran</h4>
                            <div class="payment-summary">
                                <?php 
                                $total_paid = 0;
                                $total_pending = 0;
                                $total_verified = 0;
                                
                                foreach ($comp_data['athletes'] as $athlete) {
                                    switch($athlete['payment_status']) {
                                        case 'paid': $total_paid++; break;
                                        case 'verified': $total_verified++; break;
                                        case 'pending': $total_pending++; break;
                                    }
                                }
                                ?>
                                
                                <div class="summary-item">
                                    <span class="summary-label">Total Atlet:</span>
                                    <span class="summary-value"><?php echo count($comp_data['athletes']); ?> atlet</span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Sudah Bayar:</span>
                                    <span class="summary-value text-info"><?php echo $total_paid; ?> atlet</span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Terverifikasi:</span>
                                    <span class="summary-value text-success"><?php echo $total_verified; ?> atlet</span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Menunggu:</span>
                                    <span class="summary-value text-warning"><?php echo $total_pending; ?> atlet</span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Payment Upload Modal -->
    <div id="paymentModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Upload Bukti Pembayaran</h3>
                <span class="close" onclick="closePaymentModal()">&times;</span>
            </div>
            <div class="modal-body">
                <form id="paymentForm" enctype="multipart/form-data">
                    <input type="hidden" id="registrationId" name="registration_id">
                    <div class="form-group">
                        <label for="paymentProof">Bukti Pembayaran *</label>
                        <input type="file" id="paymentProof" name="payment_proof" accept="image/*" required>
                        <small class="form-help">Format: JPG, PNG, GIF. Maksimal 5MB.</small>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn-primary">
                            <i class="fas fa-upload"></i> Upload
                        </button>
                        <button type="button" class="btn-secondary" onclick="closePaymentModal()">
                            <i class="fas fa-times"></i> Batal
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Registration Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Edit Pendaftaran</h3>
                <span class="close" onclick="closeEditModal()">&times;</span>
            </div>
            <div class="modal-body">
                <form id="editForm">
                    <input type="hidden" id="editRegistrationId" name="registration_id">
                    <input type="hidden" id="editCompetitionId" name="competition_id">
                    
                    <div class="form-group">
                        <label for="editAthlete">Ganti Atlet</label>
                        <select id="editAthlete" name="athlete_id">
                            <option value="">Pilih Atlet Lain</option>
                        </select>
                        <small class="form-help">Pilih atlet lain untuk mengganti atlet yang sudah terdaftar</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="editAgeCategory">Kategori Umur *</label>
                        <select id="editAgeCategory" name="age_category_id" required onchange="loadCompetitionCategories()">
                            <option value="">Pilih Kategori Umur</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="editCategory">Kategori Tanding</label>
                        <select id="editCategory" name="category_id">
                            <option value="">Pilih Kategori Tanding</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="editCompetitionType">Jenis Kompetisi *</label>
                        <select id="editCompetitionType" name="competition_type_id" required>
                            <option value="">Pilih Jenis Kompetisi</option>
                        </select>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn-primary">
                            <i class="fas fa-save"></i> Simpan Perubahan
                        </button>
                        <button type="button" class="btn-secondary" onclick="closeEditModal()">
                            <i class="fas fa-times"></i> Batal
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Konfirmasi Hapus</h3>
                <span class="close" onclick="closeDeleteModal()">&times;</span>
            </div>
            <div class="modal-body">
                <div class="delete-confirmation">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h4>Yakin ingin menghapus pendaftaran?</h4>
                    <p id="deleteMessage">Pendaftaran atlet akan dihapus secara permanen.</p>
                    
                    <form id="deleteForm" method="POST">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" id="deleteRegistrationId" name="registration_id">
                        
                        <div class="form-actions">
                            <button type="submit" class="btn-danger">
                                <i class="fas fa-trash"></i> Ya, Hapus
                            </button>
                            <button type="button" class="btn-secondary" onclick="closeDeleteModal()">
                                <i class="fas fa-times"></i> Batal
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="../../assets/js/script.js"></script>
    <script>
        function uploadPayment(registrationId) {
            document.getElementById('registrationId').value = registrationId;
            document.getElementById('paymentModal').style.display = 'block';
        }

        function closePaymentModal() {
            document.getElementById('paymentModal').style.display = 'none';
        }

        function editRegistration(registrationId, competitionId) {
            document.getElementById('editRegistrationId').value = registrationId;
            document.getElementById('editCompetitionId').value = competitionId;
            
            // Load available athletes for replacement
            loadAvailableAthletes();
            
            // Load categories for this competition
            loadEditData(competitionId);
            
            document.getElementById('editModal').style.display = 'block';
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        function deleteRegistration(registrationId, athleteName) {
            document.getElementById('deleteRegistrationId').value = registrationId;
            document.getElementById('deleteMessage').textContent = `Pendaftaran atlet "${athleteName}" akan dihapus secara permanen.`;
            document.getElementById('deleteModal').style.display = 'block';
        }

        function closeDeleteModal() {
            document.getElementById('deleteModal').style.display = 'none';
        }

        function generateInvoice(id, type) {
            // Open invoice in new window
            const url = type === 'athlete' 
                ? `generate-invoice.php?registration_id=${id}&type=athlete`
                : `generate-invoice.php?competition_id=${id}&type=kontingen`;
            
            window.open(url, '_blank');
        }

        function loadAvailableAthletes() {
            fetch('get-available-athletes.php')
                .then(response => response.json())
                .then(data => {
                    const select = document.getElementById('editAthlete');
                    select.innerHTML = '<option value="">Pilih Atlet Lain</option>';
                    data.forEach(athlete => {
                        select.innerHTML += `<option value="${athlete.id}">${athlete.nama} (${athlete.jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'})</option>`;
                    });
                });
        }

        function loadEditData(competitionId) {
            // Load age categories
            fetch(`get-competition-data.php?competition_id=${competitionId}&type=age_categories`)
                .then(response => response.json())
                .then(data => {
                    const select = document.getElementById('editAgeCategory');
                    select.innerHTML = '<option value="">Pilih Kategori Umur</option>';
                    data.forEach(item => {
                        select.innerHTML += `<option value="${item.id}">${item.nama_kategori} (${item.usia_min}-${item.usia_max} tahun)</option>`;
                    });
                });

            // Load competition types
            fetch(`get-competition-data.php?competition_id=${competitionId}&type=competition_types`)
                .then(response => response.json())
                .then(data => {
                    const select = document.getElementById('editCompetitionType');
                    select.innerHTML = '<option value="">Pilih Jenis Kompetisi</option>';
                    data.forEach(item => {
                        const price = item.biaya_pendaftaran ? `Rp ${parseInt(item.biaya_pendaftaran).toLocaleString('id-ID')}` : 'Gratis';
                        select.innerHTML += `<option value="${item.id}">${item.nama_kompetisi} - ${price}</option>`;
                    });
                });
        }

        function loadCompetitionCategories() {
            const ageCategoryId = document.getElementById('editAgeCategory').value;
            const competitionId = document.getElementById('editCompetitionId').value;
            
            if (ageCategoryId && competitionId) {
                fetch(`get-competition-data.php?competition_id=${competitionId}&type=competition_categories&age_category_id=${ageCategoryId}`)
                    .then(response => response.json())
                    .then(data => {
                        const select = document.getElementById('editCategory');
                        select.innerHTML = '<option value="">Pilih Kategori Tanding</option>';
                        data.forEach(item => {
                            const weight = (item.berat_min || item.berat_max) ? ` (${item.berat_min}-${item.berat_max} kg)` : '';
                            select.innerHTML += `<option value="${item.id}">${item.nama_kategori}${weight}</option>`;
                        });
                    });
            }
        }

        // Handle payment form submission
        document.getElementById('paymentForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('upload-payment.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Bukti pembayaran berhasil diupload!');
                    closePaymentModal();
                    location.reload();
                } else {
                    alert('Gagal upload bukti pembayaran: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Terjadi kesalahan saat upload');
            });
        });

        // Handle edit form submission
        document.getElementById('editForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('update-registration.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Pendaftaran berhasil diperbarui!');
                    closeEditModal();
                    location.reload();
                } else {
                    alert('Gagal memperbarui pendaftaran: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Terjadi kesalahan saat memperbarui');
            });
        });

        // Close modal when clicking outside
        window.onclick = function(event) {
            const paymentModal = document.getElementById('paymentModal');
            const editModal = document.getElementById('editModal');
            const deleteModal = document.getElementById('deleteModal');
            
            if (event.target == paymentModal) {
                paymentModal.style.display = 'none';
            }
            if (event.target == editModal) {
                editModal.style.display = 'none';
            }
            if (event.target == deleteModal) {
                deleteModal.style.display = 'none';
            }
        }
    </script>

    <style>
        .registrations-container {
            display: flex;
            flex-direction: column;
            gap: 30px;
        }

        .competition-registration-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .competition-header {
            background: var(--light-color);
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
        }

        .competition-info h3 {
            color: var(--primary-color);
            margin: 0 0 10px 0;
        }

        .competition-meta {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .competition-date {
            color: var(--text-light);
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .athletes-list {
            padding: 20px;
        }

        .athletes-list h4 {
            color: var(--primary-color);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .athletes-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .athlete-registration-card {
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 15px;
            background: #fafafa;
        }

        .athlete-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .athlete-header strong {
            color: var(--text-color);
        }

        .payment-status {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .athlete-details {
            margin-bottom: 15px;
        }

        .detail-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
            font-size: 0.9rem;
        }

        .detail-label {
            color: var(--text-light);
            font-weight: 600;
        }

        .price-amount {
            color: var(--success-color);
            font-weight: 600;
        }

        .athlete-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .kontingen-actions {
            text-align: center;
            padding: 15px;
            border-top: 1px solid var(--border-color);
            background: #f8f9fa;
        }

        .payment-info {
            padding: 20px;
            background: var(--light-color);
            border-top: 1px solid var(--border-color);
        }

        .payment-info h4 {
            color: var(--primary-color);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .payment-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        .summary-item {
            display: flex;
            justify-content: space-between;
            padding: 10px;
            background: white;
            border-radius: 6px;
            border-left: 3px solid var(--primary-color);
        }

        .summary-label {
            color: var(--text-light);
            font-weight: 600;
        }

        .summary-value {
            font-weight: 600;
        }

        .text-info { color: #17a2b8; }
        .text-success { color: #28a745; }
        .text-warning { color: #ffc107; }

        .btn-action {
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 0.8rem;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            border: none;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-pay {
            background: #28a745;
            color: white;
        }

        .btn-pay:hover {
            background: #218838;
        }

        .btn-edit {
            background: #ffc107;
            color: #212529;
        }

        .btn-edit:hover {
            background: #e0a800;
        }

        .btn-delete {
            background: #dc3545;
            color: white;
        }

        .btn-delete:hover {
            background: #c82333;
        }

        .btn-invoice {
            background: #6c757d;
            color: white;
        }

        .btn-invoice:hover {
            background: #5a6268;
        }

        /* Status badges */
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-coming_soon {
            background-color: #fff3cd;
            color: #856404;
        }

        .status-open_regist {
            background-color: #d4edda;
            color: #155724;
        }

        .status-close_regist {
            background-color: #f8d7da;
            color: #721c24;
        }

        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }

        .status-paid {
            background-color: #d1ecf1;
            color: #0c5460;
        }

        .status-verified {
            background-color: #d4edda;
            color: #155724;
        }

        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }

        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 0;
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
            max-height: 80vh;
            overflow-y: auto;
        }

        .modal-header {
            padding: 20px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--light-color);
        }

        .modal-header h3 {
            margin: 0;
            color: var(--primary-color);
        }

        .close {
            color: var(--text-light);
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .close:hover {
            color: var(--text-color);
        }

        .modal-body {
            padding: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: var(--text-color);
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 14px;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(var(--primary-color-rgb), 0.2);
        }

        .form-help {
            font-size: 0.8rem;
            color: var(--text-light);
            margin-top: 5px;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 20px;
        }

        .delete-confirmation {
            text-align: center;
        }

        .delete-confirmation i {
            font-size: 3rem;
            color: #dc3545;
            margin-bottom: 15px;
        }

        .delete-confirmation h4 {
            color: var(--text-color);
            margin-bottom: 10px;
        }

        .delete-confirmation p {
            color: var(--text-light);
            margin-bottom: 20px;
        }

        .btn-danger {
            background: #dc3545;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: background 0.3s;
        }

        .btn-danger:hover {
            background: #c82333;
        }

        @media (max-width: 768px) {
            .competition-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .competition-meta {
                flex-direction: column;
                align-items: flex-start;
                gap: 8px;
            }

            .athletes-grid {
                grid-template-columns: 1fr;
            }

            .payment-summary {
                grid-template-columns: 1fr;
            }

            .athlete-actions {
                flex-direction: column;
            }

            .modal-content {
                width: 95%;
                margin: 10% auto;
            }

            .form-actions {
                flex-direction: column;
            }
        }
    </style>
</body>
</html>
